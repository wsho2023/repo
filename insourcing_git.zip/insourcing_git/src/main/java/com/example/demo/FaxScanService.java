package com.example.demo;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import common.fax.FaxScanFile;
import common.utils.MyFiles;
import common.utils.MyUtils;

@Service
@EnableScheduling
public class FaxScanService {

    @Autowired
    private SpringConfig config;
	FaxScanFile scan1;
	FaxScanFile scan2;
	String kyoten1;
	String kyoten2;
    int count;
    String watchdogPath;

	/*public void run(SpringConfig config, String kyoten) {
		String targetPath;
		FaxScanFile scan;
		
		scan = new FaxScanFile(config, kyoten);
		targetPath = scan.scanGetTargetPath();
		scan.scanRemainedFile();	//すでにフォルダにあるpdfをScan
		//指定ディレクトリ配下のファイルのみ(またはディレクトリ)を取得
		// https://qiita.com/fumikomatsu/items/67f012b364dda4b03bf1
		try {
	        WatchService watcher;
			watcher = FileSystems.getDefault().newWatchService();
			Path dir = Paths.get(targetPath);
			dir.register(watcher, ENTRY_CREATE, ENTRY_DELETE, ENTRY_MODIFY);
			MyUtils.SystemLogPrint("■FaxScanService: start..." + targetPath);
	        for (;;) {
	            WatchKey watchKey = watcher.take();
	            for (WatchEvent<?> event: watchKey.pollEvents()) {
	                if (event.kind() == OVERFLOW) continue;
	                //新規作成
	                if (event.kind() == ENTRY_CREATE) {
	                    WatchEvent<Path> ev = cast(event);
	                    Path name = ev.context();		//ファイル名
	                    Path src = dir.resolve(name);	//フルパス
	                    String fileName = name.toString();
	                    System.out.format("%s: %s %s\n", event.kind().name(), src, name);
	                    //String extension = fileName.substring(fileName.lastIndexOf("."));	//
	                    String extension = fileName.substring(fileName.length()-3);	//拡張子：後ろから3文字
	                    if (extension.equals("pdf") == true) {
                    		MyUtils.SystemLogPrint("  ファイル検出: " + fileName);
                    		scan.scanProcess(fileName);
	                    }
	                }
	            }
	            watchKey.reset();
	        }
		} catch (IOException | InterruptedException e) {
			e.printStackTrace();
		} catch (Throwable e) {
			e.printStackTrace();
		}
	}
	
	@SuppressWarnings("unchecked")
    static <T> WatchEvent<T> cast(WatchEvent<?> event) {
        return (WatchEvent<T>)event;
    }*/

	@Scheduled(fixedRate = 20000)	// 20000ms間隔
	public void runProcess() {
		if (scan1 == null) {
			MyUtils.SystemErrPrint("FaxScan1 Initialization...");
			kyoten1 = config.getScanDefTgt1();
			scan1 = new FaxScanFile(config, kyoten1);
			MyUtils.SystemLogPrint("■FaxScanService: start..." + scan1.scanGetTargetPath());
		}
		MyUtils.SystemLogPrint("■FaxScan.runProcess: " + scan1.scanGetTargetPath());
	    scan1.scanRemainedFile();	//すでにフォルダにあるpdfをScan
		if (scan2 == null) {
			MyUtils.SystemErrPrint("FaxScan2 Initialization...");
			kyoten2 = config.getScanDefTgt2();
			scan2 = new FaxScanFile(config, kyoten2);
			MyUtils.SystemLogPrint("■FaxScanService: start..." + scan2.scanGetTargetPath());
			watchdogPath = scan2.scanGetTargetPath() + "data\\watchdog_scan.dat";
			count = 0;
		}
		MyUtils.SystemLogPrint("■FaxScan.runProcess: " + scan2.scanGetTargetPath());
	    scan2.scanRemainedFile();	//すでにフォルダにあるpdfをScan

	    // 定期的に実行したい処理
	    count++;
	    //MyUtils.SystemLogPrint(count + "回目のタスクが実行されました。");
	    //---------------------------------
	    //watchdog 書き込み処理
		try {
			String str = MyUtils.getDate()+"\n" + count+"\n";
			MyFiles.writeString2File(str, watchdogPath);
		} catch (IOException e){
			MyUtils.SystemErrPrint(e.toString());
		}
	    //---------------------------------
    }
}
