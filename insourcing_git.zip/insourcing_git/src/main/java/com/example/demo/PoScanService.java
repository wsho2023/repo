package com.example.demo;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import common.po.PoScanFile;
import common.utils.MyFiles;
import common.utils.MyUtils;

@Service
@EnableScheduling
public class PoScanService {

    @Autowired
    private SpringConfig config;
	PoScanFile scan;
    int count;
    String watchdogPath;

	/*@Async
	public void run(SpringConfig config, String targetPath) {
		PoScanFile scan;
		
		scan = new PoScanFile(config, targetPath);
		scan.scanRemainedFile();	//すでにフォルダにあるpdfをScan
		//指定ディレクトリ配下のファイルのみ(またはディレクトリ)を取得
		// https://qiita.com/fumikomatsu/items/67f012b364dda4b03bf1
		try {
	        WatchService watcher;
			watcher = FileSystems.getDefault().newWatchService();
			Path dir = Paths.get(targetPath);
			dir.register(watcher, ENTRY_CREATE, ENTRY_DELETE, ENTRY_MODIFY);
			MyUtils.SystemLogPrint("■PoScanService: start..." + targetPath);
	        for (;;) {
	            WatchKey watchKey = watcher.take();
	            for (WatchEvent<?> event: watchKey.pollEvents()) {
	                if (event.kind() == OVERFLOW) continue;
	                //新規作成
	                if (event.kind() == ENTRY_CREATE) {
	                    WatchEvent<Path> ev = cast(event);
	                    Path name = ev.context();		//ファイル名
	                    Path src = dir.resolve(name);	//フルパス
	                    String fileName = name.toString();
	                    System.out.format("%s: %s %s\n", event.kind().name(), src, name);
						if (MyFiles.isFile(src.toString())) {
                    		MyUtils.SystemLogPrint("  ファイル検出: " + fileName);
                    		scan.scanProcess(src.toString());
						}
	                }
	            }
	            watchKey.reset();
	        }
		} catch (IOException | InterruptedException e) {
			e.printStackTrace();
		} catch (Throwable e) {
			e.printStackTrace();
		}
	}
	
	@SuppressWarnings("unchecked")
    static <T> WatchEvent<T> cast(WatchEvent<?> event) {
        return (WatchEvent<T>)event;
    }*/
	
	@Scheduled(fixedRate = 20000)	// 20000ms間隔
	public void runProcess() {
		if (scan == null) {
			MyUtils.SystemErrPrint("PoScan Initialization...");
			scan = new PoScanFile(config, config.getOcrUploadPath1());
			MyUtils.SystemLogPrint("■PoScanService: start..." + scan.scanGetTargetPath());
			watchdogPath = scan.scanGetTargetPath() + "done\\watchdog_scan.dat";
			count = 0;
		}
		MyUtils.SystemLogPrint("■PoScan.runProcess: " + scan.scanGetTargetPath());
	    // 定期的に実行したい処理
	    count++;
	    //MyUtils.SystemLogPrint(count + "回目のタスクが実行されました。");
	    scan.scanRemainedFile();	//すでにフォルダにあるpdfをScan
	    //---------------------------------
	    //watchdog 書き込み処理
		try {
			String str = MyUtils.getDate()+"\n" + count+"\n";
			MyFiles.writeString2File(str, watchdogPath);
		} catch (IOException e){
			MyUtils.SystemErrPrint(e.toString());
		}                
	    //---------------------------------
    }
}
