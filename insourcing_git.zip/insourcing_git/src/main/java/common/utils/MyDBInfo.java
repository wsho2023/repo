package common.utils;

public class MyDBInfo {
	public String URL;
	public String USER;
	public String PASS;
	public String DRIVER;

	public MyDBInfo(String argURL, String argUSER, String argPASS, String argDRIVER) {
	    //接続情報取得
		URL = argURL;
		USER = argUSER;
		PASS = argPASS;
		DRIVER = argDRIVER;
	}
}