package tools.statuschange;

import java.util.MissingResourceException;
import java.util.ResourceBundle;
import java.util.Timer;
import java.util.TimerTask;

import common.utils.MyDBInfo;
import common.utils.MyMail;
import common.utils.MyUtils;

public class StatusChangeProcess2 {
	static MyDBInfo dBInfo;
	static MyMail mailConf;
	static String nowDate;
	static String preDate;

	static void getProperty() throws MissingResourceException {
		ResourceBundle rb = ResourceBundle.getBundle("prop");
		dBInfo = new MyDBInfo(
				rb.getString("DB_URL"),
				rb.getString("DB_USER"),
				rb.getString("DB_PASS"),
				rb.getString("DB_DRIVER"));
		mailConf = new MyMail();
		mailConf.host = rb.getString("MAIL_HOST");
		mailConf.port = rb.getString("MAIL_PORT");
		mailConf.username = rb.getString("MAIL_USER");
		mailConf.password = rb.getString("MAIL_PASS");
		mailConf.smtpAuth = rb.getString("MAIL_SMTP_AUTH");
		mailConf.starttlsEnable = rb.getString("MAIL_SMTP_STARTTLS_ENABLE");
	}

	public static void main(String[] args) {
		try {
			getProperty();
		} catch (MissingResourceException e) {
			e.printStackTrace();
			String msg = e.toString();
			MyUtils.SystemErrPrint(msg);
			//sendResultMail(msg, null);
			return;
		}
		preDate = MyUtils.getDateStrDateFormat(0, "yyyy/MM/dd HH:mm:ss");
		CallableExecute sdao = new CallableExecute(dBInfo);
		String sql = "call print_date(?)";	//{}あってもなくても一緒
        sdao.connect(sql);

        Timer timer = new Timer(); // 今回追加する処理
        TimerTask task = new TimerTask() {
            int count = 0;
            String resultStr = "";
            public void run() {
                count++;
                nowDate = MyUtils.getDateStrDateFormat(0, "yyyy/MM/dd HH:mm:ss");
                resultStr = sdao.execute();
                System.out.println("1:" + count + "回目のタスク("+resultStr+")");
            }
        };
        timer.scheduleAtFixedRate(task, 1000, 3000); // 今回追加する処理

		CallableExecute sdao2 = new CallableExecute(dBInfo);
		String sql2 = "call print_date(?)";	//{}あってもなくても一緒
        sdao2.connect(sql2);

        Timer timer2 = new Timer(); // 今回追加する処理
        TimerTask task2 = new TimerTask() {
            int count = 0;
            String resultStr = "";
            public void run() {
                count++;
                nowDate = MyUtils.getDateStrDateFormat(0, "yyyy/MM/dd HH:mm:ss");
                resultStr = sdao.execute();
                System.out.println("2:" + count + "回目のタスク("+resultStr+")");
            }
        };
        timer2.scheduleAtFixedRate(task2, 1000, 5000); // 今回追加する処理
	}
}
