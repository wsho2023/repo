package tools.statuschange;

import com.fasterxml.jackson.annotation.JsonProperty;

public class StatusChangeBean {
	@JsonProperty("ID")	int ID;
	@JsonProperty("Name") String Name;
	@JsonProperty("BirthYear")	 int BirthYear;
	@JsonProperty("BirthMonth")	 int BirthMonth;
	@JsonProperty("BirthDay") int BirthDay;
	@JsonProperty("SEX")	String Sex;

	public String getUserId() {	return null;	}
	public String getTaskName() {	return null;	}
	public String getTaskStatus() {	return null;	}
    public String getDataText() {
		String line = this.ID + "\t" + this.Name + "\t" + this.BirthYear + "\t" +
					  this.BirthMonth + "\t" + this.BirthDay + "\t" + this.Sex;

		return line;
	}

}
