package tools.statuschange;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Types;

import common.utils.MyDBInfo;


public class CallableExecute  {
	//DB接続情報
	String DB_URL;
	String DB_USER;
	String DB_PASS;
	String DB_DRIVER;
	Connection conn;
	CallableStatement cs;

	public CallableExecute(MyDBInfo dBInfo) {
        //接続情報取得
		DB_URL = dBInfo.URL;
		DB_USER = dBInfo.USER;
		DB_PASS = dBInfo.PASS;
		DB_DRIVER = dBInfo.DRIVER;
		conn = null;
		cs = null;
	}

	//ttps://confrage.jp/javaからプロシージャを呼び出す方法/
	public void connect(String sql) {
	    //String sql = "{call INSERT_TBL(?, ?)}";
	    //String sql = "call print_date(?)";	//{}あってもなくても一緒
	
		//接続処理
		try {
			Class.forName(DB_DRIVER);
			conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
			System.out.println("  sql: " + sql);
			conn.setAutoCommit(false);

			cs = conn.prepareCall(sql);
		} catch(ClassNotFoundException e) {
			// エラーハンドリング
			System.out.println("JDBCドライバ関連エラー");
			e.printStackTrace();
		} catch(SQLException e) {
			// エラーハンドリング
			System.out.println("sql実行失敗");
			e.printStackTrace();
		}
	}

	public String execute() {
		String retMsg = "";

		try {
			// OUTパラメータ
			//cs.registerOutParameter(4, Types.INTEGER);
			cs.registerOutParameter(1, Types.VARCHAR);
			//cs.registerOutParameter(6, Types.ARRAY, "INFOARRAY");
			// INパラメータ
			//cs.setInt(1, 100);
			//cs.setString(2, "2");
			// プロシージャを実行す
			cs.executeUpdate();
	
			retMsg = cs.getString(1);
			System.out.println(retMsg);
		} catch (Exception e) {
			e.printStackTrace();
	   	}
		return retMsg;
	}

	public void close() {
		// DB接続を解除
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

}
