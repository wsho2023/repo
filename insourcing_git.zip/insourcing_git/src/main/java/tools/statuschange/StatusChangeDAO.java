package tools.statuschange;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import common.utils.MyDBInfo;

public class StatusChangeDAO  {
	//DB接続情報
	String DB_URL;
	String DB_USER;
	String DB_PASS;
	String DB_DRIVER;
	Connection conn;
	PreparedStatement ps;

	public StatusChangeDAO(MyDBInfo dBInfo) {
        //接続情報取得
		DB_URL = dBInfo.URL;
		DB_USER = dBInfo.USER;
		DB_PASS = dBInfo.PASS;
		DB_DRIVER = dBInfo.DRIVER;
	}

	public void connectDB() {
		String sql = "select * from USER_DATA "
				   + "where update_date >= ? and update_date < ? order by ID desc";
		//接続処理
		try {
			Class.forName(DB_DRIVER);
			conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
			System.out.println("  sql: " + sql);

			ps = conn.prepareStatement(sql);
		} catch(ClassNotFoundException e) {
			// エラーハンドリング
			System.out.println("JDBCドライバ関連エラー");
			e.printStackTrace();
		} catch(SQLException e) {
			// エラーハンドリング
			System.out.println("sql実行失敗");
			e.printStackTrace();
		}
	}

	public ArrayList<StatusChangeBean> queryDB(String preDate, String nowDate) {
		ArrayList<StatusChangeBean> list = new ArrayList<StatusChangeBean>();
		//System.out.println("  preDate: " + preDate + "  nowDate: " + nowDate);
		try {
			ps.setString(1, preDate);
			ps.setString(2, nowDate);
            ResultSet rs = ps.executeQuery();

            StatusChangeBean status = null;
			while (rs.next()) {
    			//Beanクラスを初期化
				status = new StatusChangeBean();
				status.ID = rs.getInt("ID");
				status.Name = rs.getString("NAME");
				status.BirthYear = rs.getInt("BIRTH_YEAR");
				status.BirthMonth = rs.getInt("BIRTH_MONTH");
				status.BirthDay = rs.getInt("BIRTH_DAY");
				status.Sex = rs.getString("SEX");
            	// リストにBeanクラスごと格納
    			list.add(status);
			}
		} catch(SQLException e) {
			// エラーハンドリング
			System.out.println("sql実行失敗");
			e.printStackTrace();
		}

		return list;
	}
}
