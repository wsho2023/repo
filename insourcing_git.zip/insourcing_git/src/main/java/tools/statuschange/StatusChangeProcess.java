package tools.statuschange;

import java.util.ArrayList;
import java.util.Date;
import java.util.MissingResourceException;
import java.util.ResourceBundle;
import java.util.Timer;
import java.util.TimerTask;

import common.utils.MyDBInfo;
import common.utils.MyMail;
import common.utils.MyUtils;

public class StatusChangeProcess {
	static MyDBInfo dBInfo;
	static MyMail mailConf;
	static String nowDate;
	static String preDate;

	static void getProperty() throws MissingResourceException {
		ResourceBundle rb = ResourceBundle.getBundle("prop");
		dBInfo = new MyDBInfo(
				rb.getString("DB_URL"),
				rb.getString("DB_USER"),
				rb.getString("DB_PASS"),
				rb.getString("DB_DRIVER"));
		mailConf = new MyMail();
		mailConf.host = rb.getString("MAIL_HOST");
		mailConf.port = rb.getString("MAIL_PORT");
		mailConf.username = rb.getString("MAIL_USER");
		mailConf.password = rb.getString("MAIL_PASS");
		mailConf.smtpAuth = rb.getString("MAIL_SMTP_AUTH");
		mailConf.starttlsEnable = rb.getString("MAIL_SMTP_STARTTLS_ENABLE");
	}

	public static void main(String[] args) {
		try {
			getProperty();
		} catch (MissingResourceException e) {
			e.printStackTrace();
			String msg = e.toString();
			MyUtils.SystemErrPrint(msg);
			//sendResultMail(msg, null);
			return;
		}
		preDate = MyUtils.getDateStrDateFormat(0, "yyyy/MM/dd HH:mm:ss");
        StatusChangeDAO sdao = new StatusChangeDAO(dBInfo);
        sdao.connectDB();

        Timer timer = new Timer(); // 今回追加する処理
        TimerTask task = new TimerTask() {
            int count = 0;
            public void run() {
                count++;
                nowDate = MyUtils.getDateStrDateFormat(0, "yyyy/MM/dd HH:mm:ss");
                ArrayList<StatusChangeBean> list = sdao.queryDB(preDate, nowDate);
                System.out.println(count + "回目のタスク("+preDate+ "～" +nowDate+ ")。");
                preDate = nowDate;
                for (StatusChangeBean status : list) {
	                MyUtils.SystemLogPrint(status.getDataText());
	                String taskName = status.getTaskName();
	                String taskStatus = status.getTaskStatus();
	                if (taskStatus.equals("0")==true || taskStatus.equals("1")==true) {
	                	//0:待機中 / 1:実行中
	                	if (taskName.equals("連携1")==true || taskName.equals("連携2")==true) {
	                		;
	                	}
	                } else if (taskStatus.equals("2")==true) {
	                	//2:正常終了
	                	taskStatus = "正常終了";
	                } else if (taskStatus.equals("3")==true) {
	                	//3:エラー停止
	                	taskStatus = "エラー停止";
	                } else if (taskStatus.equals("2")==true) {
	                	//4:警告終了
	                	taskStatus = "警告終了";
	                } else {
	                	taskStatus = "????";
	                }
	                String task;
	                if (taskName.equals("一括登録")) {
	                	task = taskName + "/" + status.getUserId();
	                } else if (taskName.equals("データ取り込み")) {
	                	task = taskName + " 件数:" + "?"; 
	                } else if (taskName.equals("連携1")==true || taskName.equals("連携2")==true) {
	                	task = taskName;
	                } else {
	                	task = taskName;
	                }
	                String msg = MyUtils.sdf.format(new Date()) + "TASK " + task + ", " + taskStatus+ ", "; 
	                mailConf.fmAddr = mailConf.username;
	                mailConf.toAddr = mailConf.fmAddr;
	        		mailConf.ccAddr = "";
	        		mailConf.bccAddr = mailConf.fmAddr;
	        		mailConf.subject = "[システム]" + msg;
	        		mailConf.body = msg;
	        		mailConf.attach =  "";
	        		MyUtils.SystemLogPrint("  メール送信...");
	        		MyUtils.SystemLogPrint("  MAIL FmAddr: " + mailConf.fmAddr);
	        		MyUtils.SystemLogPrint("  MAIL ToAddr: " + mailConf.toAddr);
	        		MyUtils.SystemLogPrint("  MAIL CcAddr: " + mailConf.ccAddr);
	        		MyUtils.SystemLogPrint("  MAIL BcAddr: " + mailConf.bccAddr);
	        		MyUtils.SystemLogPrint("  MAIL Subject: " + mailConf.subject);
	        		MyUtils.SystemLogPrint("  MAIL Body: \n" + mailConf.body);
	        		MyUtils.SystemLogPrint("  MAIL Attach: " + mailConf.attach);
	        		mailConf.sendRawMail();
                }
            }
        };
        timer.scheduleAtFixedRate(task, 1000, 3000); // 今回追加する処理
	}
}
