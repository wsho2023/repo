package tools.client;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

import org.apache.poi.ss.usermodel.Row;

import common.utils.MyExcel;
import common.utils.MyMail;
import common.utils.MyUtils;
import common.utils.WebApi;

public class Client {
	static MyMail mailConf;
	static String hostURL;

	static void getProperty() throws MissingResourceException {
		ResourceBundle rb = ResourceBundle.getBundle("prop");
        mailConf = new MyMail();
		mailConf.host = rb.getString("MAIL_HOST");
		mailConf.port = rb.getString("MAIL_PORT");
		mailConf.username = rb.getString("MAIL_USER");
		mailConf.password = rb.getString("MAIL_PASS");
		mailConf.smtpAuth = rb.getString("MAIL_SMTP_AUTH");
		mailConf.starttlsEnable = rb.getString("MAIL_SMTP_STARTTLS_ENABLE");

		mailConf.fmAddr = rb.getString("MAIL_FROM");
		mailConf.toAddr = rb.getString("MAIL_TO");
		mailConf.ccAddr = rb.getString("MAIL_CC");
		mailConf.bccAddr = rb.getString("MAIL_BCC");

		hostURL = rb.getString("HOST_URL");
	}

	public static void main(String[] args) {
		if (args.length != 1 && args.length != 2) {
		    System.out.println("引数を1or2つ指定して下さい");
		    System.exit(1);
		}
		int clientMode;
		System.out.println("args[0]: " + args[0]);
		String fileName = args[0];
		String saveFilePath = "";
		clientMode = 1; 
		if (args.length == 2) {
			System.out.println("args[1]: " + args[1]);
			saveFilePath = args[1];
			clientMode = 2;
		}

		//----------------------------------------------------------------------
		long elapsed  = System.currentTimeMillis();
		//System.out.println("elapsed: " + elapsed);
		//----------------------------------------------------------------------
		try {
			getProperty();
		} catch (MissingResourceException e) {
			e.printStackTrace();
			String msg = e.toString();
			MyUtils.SystemErrPrint(msg);
			sendResultMail(msg, null);
			return;
		}
		String currentPath = System.getProperty("user.dir") + System.getProperty("file.separator");
		MyUtils.SystemLogPrint("現在のパス: " + currentPath);
		String xlsPath;
		try {
			//2 Excelオープン
			xlsPath = currentPath + fileName + "_DEF.xlsx";
			MyExcel xlsx = new MyExcel();
			xlsx.open(xlsPath, "設定", true);

			MyUtils.SystemLogPrint("  Excelオープン...: " + xlsPath);
			String sql = "";
			for (Row row : xlsx.sheet) {
				xlsx.row = row;
				if (xlsx.getCell(0) == true) {	//A列
					String value = xlsx.getStringCellValue();
					if (value.equals("S20_検索SQL") != true) {
						sql = sql + value;
					}
				}
			}
			System.out.println(sql);

			WebApi api = new WebApi();
			api.setUrl("POST", hostURL);
			api.putRequestHeader("Content-Type", "application/x-www-form-urlencoded");
			String encoded = URLEncoder.encode(sql, "UTF-8");
			String postData = "charset=UTF-8&sql=" + encoded;
			if (clientMode == 1) {
				ArrayList<ArrayList<String>> list = null;
				api.postDownload(postData, null, 1);	//dlFlag 0:ファイル出力 1:List読み込み
	
				//データ転記、データ転記した範囲をテーブル化
				//xlsx.setColFormat(colFmtList.get(i));
				list = api.getListData();
				xlsx.writeData("明細", list, true);
	
				//Excelファイル保存
				xlsPath = currentPath + fileName + ".xlsx";
				MyUtils.SystemLogPrint("  XLSXファイル保存: " + xlsPath);
				xlsx.save(xlsPath);	//名前を付けて保存
				xlsx.close();
			} else if (clientMode == 2) {
				api.postDownload(postData, saveFilePath, 0);	//dlFlag 0:ファイル出力 1:List読み込み
				xlsx.close();
			}

		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
			String msg = e.toString();
			MyUtils.SystemErrPrint(msg);
			sendResultMail(msg, null);
			return;
		} catch (IOException e) {
			e.printStackTrace();
			String msg = e.toString();
			MyUtils.SystemErrPrint(msg);
			sendResultMail(msg, null);
			return;
		}

        //---------------------------------------------
        //添付メール送信
        //---------------------------------------------
		String dateStr = MyUtils.getDateStrDateFormat(0, "yyyy/MM/dd HH:mm:ss");
		if (clientMode == 1) {
			mailConf.subject = "DB抽出データ連絡(" + fileName + " " + dateStr +")";
			mailConf.body = "";
			mailConf.attach = xlsPath;
		} else if (clientMode == 2) {
			mailConf.subject = "DBダウンロード連絡(" + fileName + " " + dateStr +")";
			mailConf.body = "Save Path: \n" + saveFilePath;
			mailConf.attach = "";
		}

		MyUtils.SystemLogPrint("  メール送信...");
		MyUtils.SystemLogPrint("  MAIL FmAddr: " + mailConf.fmAddr);
		MyUtils.SystemLogPrint("  MAIL ToAddr: " + mailConf.toAddr);
		MyUtils.SystemLogPrint("  MAIL CcAddr: " + mailConf.ccAddr);
		MyUtils.SystemLogPrint("  MAIL BcAddr: " + mailConf.bccAddr);
		MyUtils.SystemLogPrint("  MAIL Subject: " + mailConf.subject);
		MyUtils.SystemLogPrint("  MAIL Body: \n" + mailConf.body);
		MyUtils.SystemLogPrint("  MAIL Attach: " + mailConf.attach);
    	mailConf.sendRawMail();

		//----------------------------------------------------------------------
		long elapsed2  = System.currentTimeMillis();
		//System.out.println("elapsed: " + elapsed2);
		elapsed = (long)((elapsed2 - elapsed)/1000);
		MyUtils.SystemLogPrint("経過: " + elapsed + " 秒");
		//----------------------------------------------------------------------
	}

	private static void sendResultMail(String msg, String attachFilePath) {
		String dateStr = MyUtils.getDateStrDateFormat(0, "yyyy/MM/dd HH:mm:ss");
		if (msg.equals("正常終了") == true)
			mailConf.subject = "[]完了連絡("+dateStr+")";
		else
			mailConf.subject = "[]エラー連絡("+dateStr+")";
		mailConf.body = msg + "\n";
		mailConf.attach = attachFilePath;
		MyUtils.SystemLogPrint("  メール送信...");
		MyUtils.SystemLogPrint("  MAIL FmAddr: " + mailConf.fmAddr);
		MyUtils.SystemLogPrint("  MAIL ToAddr: " + mailConf.toAddr);
		MyUtils.SystemLogPrint("  MAIL CcAddr: " + mailConf.ccAddr);
		MyUtils.SystemLogPrint("  MAIL BcAddr: " + mailConf.bccAddr);
		MyUtils.SystemLogPrint("  MAIL Subject: " + mailConf.subject);
		MyUtils.SystemLogPrint("  MAIL Body: \n" + mailConf.body);
		MyUtils.SystemLogPrint("  MAIL Attach: " + mailConf.attach);
    	mailConf.sendRawMail();
	}
}
