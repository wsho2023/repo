package tools.attachsendmail;

import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.nio.file.NoSuchFileException;
import java.util.ArrayList;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

import common.utils.MyExcel;
import common.utils.MyFiles;
import common.utils.MyMail;
import common.utils.MyUtils;

public class AttachSendMail {
	static MyMail mailConf;
	static String targetPath;
	static String xlsPath;

	static void getProperty() throws MissingResourceException {
		ResourceBundle rb = ResourceBundle.getBundle("prop");
        mailConf = new MyMail();
		mailConf.host = rb.getString("MAIL_HOST");
		mailConf.port = rb.getString("MAIL_PORT");
		mailConf.username = rb.getString("MAIL_USER");
		mailConf.password = rb.getString("MAIL_PASS");
		mailConf.smtpAuth = rb.getString("MAIL_SMTP_AUTH");
		mailConf.starttlsEnable = rb.getString("MAIL_SMTP_STARTTLS_ENABLE");

		mailConf.fmAddr = rb.getString("MAIL_FROM");
		mailConf.toAddr = rb.getString("MAIL_USER");
		mailConf.ccAddr = rb.getString("MAIL_CC");
		mailConf.bccAddr = rb.getString("MAIL_BCC");

		targetPath = rb.getString("TARGET_PATH1");
		xlsPath = rb.getString("TARGET_FILE1");
	}

	public static void main(String[] args) {
		//----------------------------------------------------------------------
		long elapsed  = System.currentTimeMillis();
		//System.out.println("elapsed: " + elapsed);
		//----------------------------------------------------------------------
		try {
			getProperty();
		} catch (MissingResourceException e) {
			e.printStackTrace();
			String msg = e.toString();
			MyUtils.SystemErrPrint(msg);
			sendResultMail(msg);
			return;
		}
		MyUtils.SystemLogPrint("現在のパス: " + System.getProperty("user.dir"));
        MyUtils.SystemLogPrint("SCANパス: " + targetPath);

		//指定ディレクトリ内のファイルのみ(またはディレクトリのみ)を取得
        File file = new File(targetPath);
        File fileArray[] = file.listFiles(filter);
        if (fileArray == null) {
			String msg = "指定ディレクトリ接続不可";
			MyUtils.SystemErrPrint(msg);
			sendResultMail(msg);
			return;
        }
        ArrayList<String> attach = new ArrayList<String>(); 
        for (File f: fileArray) {
            attach.add(f.toString());
        }
        if (attach.size() < 1) {
			String msg = "対象ファイルなしのため終了";
			MyUtils.SystemLogPrint(msg);
        	return;
        }

        //---------------------------------------------
        //添付メール送信
        //---------------------------------------------
		try {
			getMailConf();
		} catch (IOException e) {
			e.printStackTrace();
			String msg = e.toString();
			MyUtils.SystemErrPrint(msg);
			sendResultMail(msg);
			return;
		}
		MyUtils.SystemLogPrint("  メール送信...");
		MyUtils.SystemLogPrint("  MAIL FmAddr: " + mailConf.fmAddr);
		MyUtils.SystemLogPrint("  MAIL ToAddr: " + mailConf.toAddr);
		MyUtils.SystemLogPrint("  MAIL CcAddr: " + mailConf.ccAddr);
		MyUtils.SystemLogPrint("  MAIL BcAddr: " + mailConf.bccAddr);
		MyUtils.SystemLogPrint("  MAIL Subject: " + mailConf.subject);
		MyUtils.SystemLogPrint("  MAIL Body: \n" + mailConf.body);
		//MyUtils.SystemLogPrint("  MAIL Attach: " + mailConf.attach);
		MyUtils.SystemLogPrint("  MAIL Attach:");
		for (String filePath : attach)
			MyUtils.SystemLogPrint("  " + filePath);
    	mailConf.sendRawMail2(attach);

	    //------------------------------------------------------
	    //フォルダへ退避（doneフォルダへ移動）
	    //------------------------------------------------------
        for (File f: fileArray) {
        	String srcPath = f.toString();
    		String fileName = MyFiles.getFileName(srcPath);
    	    String dstPath = targetPath + "done\\" + fileName;
    		try {
    			MyFiles.moveOW(srcPath, dstPath);	//上書き移動
    		} catch (NoSuchFileException e) {
    			e.printStackTrace();
    			return;	//★あやしいので、いったん、登録処理はしない。
    		} catch (IOException e) {
    			e.printStackTrace();
    			return;	//★あやしいので、いったん、登録処理はしない。
    		}
        	MyUtils.SystemLogPrint("ファイル移動: " + dstPath);
        }

		//----------------------------------------------------------------------
		long elapsed2  = System.currentTimeMillis();
		//System.out.println("elapsed: " + elapsed2);
		elapsed = (long)((elapsed2 - elapsed)/1000);
		MyUtils.SystemLogPrint("経過: " + elapsed + " 秒");
		//----------------------------------------------------------------------
	}

	//フィルタを作成する:zipファイル
	static FilenameFilter filter = new FilenameFilter() {
		public boolean accept(File file, String str){
			// 拡張子を指定する
			if (str.endsWith("zip")){
				return true;
			} else {
				return false;
			}
		}
	};

	static int getMailConf() throws IOException {
		String mailBody1;
		String mailBody2;
		//2 Excelオープン
		MyExcel xlsx = new MyExcel();
		xlsx.open(xlsPath, "MAIL", true);
		MyUtils.SystemLogPrint("  Excelオープン...: " + xlsPath);

		mailConf.fmAddr = xlsx.getStringCellValue(0, 1);	//配信メール情報:From
		mailConf.toAddr = xlsx.getStringCellValue(1, 1);	//配信メール情報:To
		mailConf.ccAddr = xlsx.getStringCellValue(2, 1);	//配信メール情報:Cc
		mailConf.bccAddr = xlsx.getStringCellValue(3, 1);	//配信メール情報:Bcc
		mailConf.subject = xlsx.getStringCellValue(4, 1);	//配信メール情報:Title
		mailBody1 = xlsx.getStringCellValue(5, 1);			//配信メール情報:Body1
		mailBody2 = xlsx.getStringCellValue(6, 1);			//配信メール情報:Body2
		mailConf.body = mailBody1 + "\n" + mailBody2 + "\n";

		xlsx.close();

		return 0;
	}

	private static void sendResultMail(String msg) {
		String dateStr = MyUtils.getDateStrDateFormat(0, "yyyy/MM/dd HH:mm:ss");
		if (msg.equals("正常終了") == true)
			mailConf.subject = "[]完了連絡("+dateStr+")";
		else
			mailConf.subject = "[]エラー連絡("+dateStr+")";
		mailConf.body = msg + "\n";
		MyUtils.SystemLogPrint("  メール送信...");
		MyUtils.SystemLogPrint("  MAIL FmAddr: " + mailConf.fmAddr);
		MyUtils.SystemLogPrint("  MAIL ToAddr: " + mailConf.toAddr);
		MyUtils.SystemLogPrint("  MAIL CcAddr: " + mailConf.ccAddr);
		MyUtils.SystemLogPrint("  MAIL BcAddr: " + mailConf.bccAddr);
		MyUtils.SystemLogPrint("  MAIL Subject: " + mailConf.subject);
		MyUtils.SystemLogPrint("  MAIL Body: \n" + mailConf.body);
    	mailConf.sendRawMail();
	}
}
