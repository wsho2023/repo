package tools.gaihitorikomi;

import java.io.IOException;
import java.util.ArrayList;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

import common.utils.MyExcel;
import common.utils.MyFiles;
import common.utils.MyMail;
import common.utils.MyUtils;

public class GaihiTorikomi {
	static MyMail mailConf;
	static String CONNECT_INFO;
	static String TABLE_NAME;
	static String CURRENT_PATH; 
	static String READ_FILE_PATH1;
	static String READ_FILE_PATH2;
	static String WRITE_PATH;
	static String BACKUP_PATH;
	static String OUTPUT_PATH;
	static String FTPBAT_PATH;
	static String COPYBAT_PATH;
	static String UPDATE_SQL;
	static String BAD_FILE_PATH;
	static String BAD_BACK_PATH;

	static void getProperty() throws MissingResourceException {
		ResourceBundle rb = ResourceBundle.getBundle("prop");
        mailConf = new MyMail();
		mailConf.host = rb.getString("MAIL_HOST");
		mailConf.port = rb.getString("MAIL_PORT");
		mailConf.username = rb.getString("MAIL_USER");
		mailConf.password = rb.getString("MAIL_PASS");
		mailConf.smtpAuth = rb.getString("MAIL_SMTP_AUTH");
		mailConf.starttlsEnable = rb.getString("MAIL_SMTP_STARTTLS_ENABLE");

		mailConf.fmAddr = rb.getString("MAIL_FROM");
		mailConf.toAddr = rb.getString("MAIL_USER");
		mailConf.ccAddr = "";
		mailConf.bccAddr = "";

		CONNECT_INFO = rb.getString("CONNECT_INFO");
		TABLE_NAME = rb.getString("TABLE_NAME");
		CURRENT_PATH = System.getProperty("user.dir") + System.getProperty("file.separator"); 
		READ_FILE_PATH1 = rb.getString("READ_FILE_PATH1");
		READ_FILE_PATH2 = rb.getString("READ_FILE_PATH2");
		WRITE_PATH = rb.getString("WRITE_PATH");
		BACKUP_PATH = rb.getString("BACKUP_PATH");
		OUTPUT_PATH = rb.getString("OUTPUT_PATH");
		FTPBAT_PATH = rb.getString("FTPBAT_PATH");
		COPYBAT_PATH = rb.getString("COPYBAT_PATH");
		UPDATE_SQL = rb.getString("UPDATE_SQL");
		BAD_FILE_PATH = rb.getString("BAD_FILE_PATH");
		BAD_BACK_PATH = rb.getString("BAD_BACK_PATH");
	}

	public static void main(String[] args) {
		//----------------------------------------------------------------------
		long elapsed  = System.currentTimeMillis();
		//System.out.println("elapsed: " + elapsed);
		//----------------------------------------------------------------------
		try {
			getProperty();
		} catch (MissingResourceException e) {
			e.printStackTrace();
			String msg = e.toString();
			MyUtils.SystemErrPrint(msg);
			sendResultMail(msg, null);
			return;
		}
		MyUtils.SystemLogPrint("現在のパス: " + System.getProperty("user.dir"));

		String[] cmdList;
		//---------------------------------------
		//①FTPから取得するバッチ実行
		//---------------------------------------
		if (MyFiles.exists(FTPBAT_PATH) != true) {
			String msg = "ファイルなしエラー: " + FTPBAT_PATH;
			MyUtils.SystemErrPrint(msg);
			sendResultMail(msg, null);
			return;
		}
		cmdList = new String[1];
		cmdList[0] = FTPBAT_PATH;
		try {
		    MyUtils.exeCmd(cmdList);
		} catch (Exception e) {
			e.printStackTrace();
			String msg = e.toString();
			MyUtils.SystemErrPrint(msg);
			sendResultMail(msg, null);
			return;
		}
		cmdList = null;

		//---------------------------------------
		//②complete.tsv(SJIS)から 前日分読込み
		//---------------------------------------
		if (MyFiles.exists(READ_FILE_PATH1) != true) {
			String msg = "ファイルなしエラー: " + READ_FILE_PATH1;
			MyUtils.SystemErrPrint(msg);
			sendResultMail(msg, null);
			return;
		}
		ArrayList<ArrayList<String>> list1 = null;
		ArrayList<ArrayList<String>> list2 = null;
		list1 = new ArrayList<ArrayList<String>>();
		try {
			//https://itsakura.com/it-shiftjis-ms932
			list1 = MyFiles.parseTSV(READ_FILE_PATH1, "MS932");	//"SJIS" or "UTF-8"
		} catch (IOException e) {
			e.printStackTrace();
        	//return e.toString();
			String msg = e.toString();
			MyUtils.SystemErrPrint(msg);
			sendResultMail(msg, null);
			return;
		}
		if (list1.size() == 0) {
			MyUtils.SystemErrPrint("抽出データなし");
		}
		String kinou = MyUtils.getToday(-1);	//前日(YYYY/MM/DD)
		String procDate11;
		list2 = new ArrayList<ArrayList<String>>();
		for (ArrayList<String> line : list1) {
			list2.add(line);
		}

		//---------------------------------------
		//③0だったら、もう1つのファイルから 前日分読込み（5のつく日）
		//---------------------------------------
		if (list2.size() == 0) {
			if (MyFiles.exists(READ_FILE_PATH2) != true) {
				String msg = "ファイルなしエラー: " + FTPBAT_PATH;
				MyUtils.SystemErrPrint(msg);
				sendResultMail(msg, null);
				return;
			}
			list2 = null;
			list1 = new ArrayList<ArrayList<String>>();
			try {
				list1 = MyFiles.parseTSV(READ_FILE_PATH2, "MS932");	//"SJIS" or "UTF-8"
			} catch (IOException e) {
				e.printStackTrace();
				String msg = e.toString();
				MyUtils.SystemErrPrint(msg);
				sendResultMail(msg, null);
				return;
			}
			kinou = MyUtils.getToday(-1);	//前日(YYYY/MM/DD)
			list2 = new ArrayList<ArrayList<String>>();
			for (ArrayList<String> line : list1) {
				procDate11 = line.get(24);	//処理日時11
				if (procDate11.equals("") != true && procDate11.equals("処理日時11") != true) {
					procDate11 = procDate11.substring(0,10);	//YYYY/MM/DDの前方10桁を抽出
					if (procDate11.equals(kinou) == true) {
						list2.add(line);
					}
				}
			}
		}

		//---------------------------------------
		//④listに格納 UTF-8.tsvに出力
		//---------------------------------------
		if (list2.size() == 0) {
			String msg = "抽出データなし"; 
			MyUtils.SystemErrPrint(msg);
			sendResultMail(msg, null);
			return;	//終了
		}

		//TSVファイル書き出し(UTF-8)
		try {
			MyFiles.writeList2File(list2, WRITE_PATH);
		} catch (IOException e) {
			e.printStackTrace();
			String msg = e.toString();
			MyUtils.SystemErrPrint(msg);
			sendResultMail(msg, null);
			return;
		}

		//---------------------------------------
		//⑤sqrldrで、TMPテーブルへロード
		//---------------------------------------
		cmdList = new String[6];
		cmdList[0] = "sqlldr";
		cmdList[1] = CONNECT_INFO;
		cmdList[2] = "control=" + TABLE_NAME + ".ctl";
		cmdList[3] = "log=" + TABLE_NAME + "_" + MyUtils.getDateStr() + ".log";
		cmdList[4] = "readsize=1000000";
		cmdList[5] = "rows=128";
		try {
		    MyUtils.exeCmd(cmdList);
		} catch (Exception e) {
			e.printStackTrace();
			String msg = e.toString();
			MyUtils.SystemErrPrint(msg);
			sendResultMail(msg, null);
			return;
		}
		cmdList = null;

		//Backupの作成
		String yomitoriDay = kinou.replace("/", "");	//YYYYMMDD
		String backupPath = String.format(BACKUP_PATH, yomitoriDay);
		try {
			MyFiles.copyOW(WRITE_PATH, backupPath);
		} catch (IOException e) {
			e.printStackTrace();
			String msg = e.toString();
			MyUtils.SystemErrPrint(msg);
			sendResultMail(msg, null);
			return;
		}

		//badファイルチェック
		if (MyFiles.exists(BAD_FILE_PATH) != true) {
			String msg = "badファイルなし";
			MyUtils.SystemLogPrint(msg);
		} else {
			//Backupの作成
			//String kinou = MyUtils.getToday(-1);	//前日(YYYY/MM/DD)
			//String yomitoriDay = kinou.replace("/", "");	//YYYYMMDD
			backupPath = CURRENT_PATH + "bad\\" + String.format(BAD_BACK_PATH, yomitoriDay);
			try {
				MyFiles.moveOW(BAD_FILE_PATH, backupPath);
			} catch (IOException e) {
				e.printStackTrace();
				String msg = e.toString();
				MyUtils.SystemErrPrint(msg);
				sendResultMail(msg, null);
				return;
			}
			String msg = "badファイル検出!";
			MyUtils.SystemErrPrint(msg);
			sendResultMail(msg, backupPath);
		}

		//⑥upload.sqlを実行（sqlplus）
		cmdList = new String[4];
		cmdList[0] = "sqlplus";
		cmdList[1] = "-S";
		cmdList[2] = CONNECT_INFO;
		cmdList[3] = "@" + UPDATE_SQL;
		try {
		    MyUtils.exeCmd(cmdList);
		} catch (Exception e) {
			e.printStackTrace();
			String msg = e.toString();
			MyUtils.SystemErrPrint(msg);
			sendResultMail(msg, null);
			return;
		}
		cmdList = null;

		//---------------------------------------
		//⑦listに格納をExcelマスタ末尾に書き込み
		//---------------------------------------
		//カーソル位置更新対応
		cmdList = new String[3];
		cmdList[0] = "cscript";
		cmdList[1] = "excelGotoLine.vbs";		//VBSファイル指定
		cmdList[2] = "/file:" + OUTPUT_PATH;
		try {
		    MyUtils.exeCmd(cmdList);
		} catch (Exception e) {
			e.printStackTrace();
			String msg = e.toString();
			MyUtils.SystemErrPrint(msg);
			sendResultMail(msg, null);
			return;
		}
		cmdList = null;

		String xlsPath = OUTPUT_PATH;
		String sheetName = "";
		MyExcel xlsx = new MyExcel();
		try {
			xlsx.openOW(xlsPath, sheetName);
		} catch (IOException e) {
			e.printStackTrace();
			String msg = e.toString();
			MyUtils.SystemErrPrint(msg);
			sendResultMail(msg, null);
			return;
		}

		int maxRow = list2.size();
		int maxCol;
		String strValue;
		int lastRow = xlsx.sheet.getLastRowNum();
		int rowIdx = lastRow + 1;	//書き込み行＝末尾行＋１
		System.out.println("書き込み開始位置: " + rowIdx);
		//1行目はヘッダのなので除去
		for (int Idx=1; Idx<maxRow; Idx++) {
			xlsx.createRow(rowIdx);			//行の生成
			maxCol = list1.get(Idx).size();
			for (int colIdx=0; colIdx<maxCol; colIdx++) {
				strValue = list2.get(Idx).get(colIdx);
				xlsx.setCellValue(colIdx, strValue);
			}
			rowIdx++;
		}
		System.out.println("書き込み終了位置: " + (rowIdx-1));
		//末尾行をアクティブセルにする。
		if (xlsx.getRow(rowIdx-1)) {
			xlsx.setAsActiveCell(0);
		}

		// 上書き保存
		try {
			xlsx.saveOW(xlsPath);
		} catch (IOException e) {
			e.printStackTrace();
			String msg = e.toString();
			MyUtils.SystemErrPrint(msg);
			sendResultMail(msg, null);
			return;
		}

		//---------------------------------------
		//⑧そのExcelマスタをサーバーへコピー
		//---------------------------------------
		cmdList = new String[1];
		cmdList[0] = COPYBAT_PATH;
		try {
		    //MyUtils.exeCmd(cmdList);
		} catch (Exception e) {
			e.printStackTrace();
			String msg = e.toString();
			MyUtils.SystemErrPrint(msg);
			sendResultMail(msg, null);
			return;
		}
		cmdList = null;

		String msg = "正常終了"; 
		MyUtils.SystemLogPrint(msg);
		sendResultMail(msg, backupPath);	//メールで送信
        //----------------------------------------------------------------------
		long elapsed2  = System.currentTimeMillis();
		//System.out.println("elapsed: " + elapsed2);
		elapsed = (long)((elapsed2 - elapsed)/1000);
		System.out.println("経過: " + elapsed + " 秒");
		//----------------------------------------------------------------------
	}

	private static void sendResultMail(String msg, String attachFilePath) {
		String dateStr = MyUtils.getDateStrDateFormat(0, "yyyy/MM/dd HH:mm:ss");
		if (msg.equals("正常終了") == true)
			mailConf.subject = "[]完了連絡("+dateStr+")";
		else
			mailConf.subject = "[]エラー連絡("+dateStr+")";
		mailConf.body = msg + "\n";
		mailConf.attach = attachFilePath;
		MyUtils.SystemLogPrint("  メール送信...");
		MyUtils.SystemLogPrint("  MAIL FmAddr: " + mailConf.fmAddr);
		MyUtils.SystemLogPrint("  MAIL ToAddr: " + mailConf.toAddr);
		MyUtils.SystemLogPrint("  MAIL CcAddr: " + mailConf.ccAddr);
		MyUtils.SystemLogPrint("  MAIL BcAddr: " + mailConf.bccAddr);
		MyUtils.SystemLogPrint("  MAIL Subject: " + mailConf.subject);
		MyUtils.SystemLogPrint("  MAIL Body: \n" + mailConf.body);
		MyUtils.SystemLogPrint("  MAIL Attach: " + mailConf.attach);
    	mailConf.sendRawMail();
	}
}
