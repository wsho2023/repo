package tools.extractfax;

import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.ResourceBundle;

import common.utils.MyFiles;

public class ScanDeleteFile {
	static int allCount;
	static int delCount;

	public static void main(String[] args) {
		String targetPath;
		String backupPath;
		int daysOfDeletion;
		System.out.println("現在のパス: " + System.getProperty("user.dir"));
		ResourceBundle rb = ResourceBundle.getBundle("prop");

		//----------------------------------------------------------------------
		long elapsed  = System.currentTimeMillis();
		//System.out.println("elapsed: " + elapsed);
		//----------------------------------------------------------------------
		allCount = 0;
		delCount = 0;
        targetPath = rb.getString("TARGET_PATH3");
		backupPath = rb.getString("BACKUP_PATH3");
		daysOfDeletion = 182;	//半年
		scanDeleteFile(targetPath, backupPath, daysOfDeletion);
		System.out.println("「" + targetPath + "」フォルダ内のファイル更新日"
				+ daysOfDeletion + "日以上のものを退避しました(スキャン数"+ allCount + ")。");
		//----------------------------------------------------------------------

		//----------------------------------------------------------------------
		allCount = 0;
		delCount = 0;
		targetPath = backupPath;
		backupPath = rb.getString("LOCAL_PATH3");;
		daysOfDeletion = 365;	//１年
		scanDeleteFile(targetPath, backupPath, daysOfDeletion);
		System.out.println("「" + targetPath + "」フォルダ内のファイル更新日"
				+ daysOfDeletion + "日以上のものを退避しました(スキャン数"+ allCount + ")。");
		//----------------------------------------------------------------------

		//----------------------------------------------------------------------
		long elapsed2  = System.currentTimeMillis();
		//System.out.println("elapsed: " + elapsed2);
		elapsed = (long)((elapsed2 - elapsed)/1000);
		System.out.println("経過: " + elapsed + " 秒");
		//----------------------------------------------------------------------
	}

	//フィルタを作成する
	static FilenameFilter filter = new FilenameFilter() {
		public boolean accept(File file, String str){
			// 拡張子を指定する
			if (str.endsWith("pdf")){
				return true;
			} else {
				return false;
			}
		}
	};

	private static void scanDeleteFile(String targetPath, String backupPath, int daysOfDeletion) {
		//指定ディレクトリ内のファイルのみ(またはディレクトリのみ)を取得
        File file = new File(targetPath);
        File fileArray[] = file.listFiles(filter);
    	SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");

        for (File f: fileArray) {
    		allCount++;
            String filePath = f.toString();
			//https://qiita.com/fumikomatsu/items/b98cc4d0dee782323096
        	// 現在日時を取得
            Calendar st = Calendar.getInstance();	//Calendarクラスで現在日時を取得
            st.add(Calendar.DATE, -daysOfDeletion);	//現在値を取得(n日前)
            Date start = st.getTime();           	//Dateに変換
            // ファイルの更新日時
            Long lastModified = f.lastModified();
            Date koushin = new Date(lastModified);	//Dateに変換

            if (start.compareTo(koushin) > 0) {		//compareToで比較
        		delCount++;
                String update_time = sdf.format(koushin);
            	System.out.println("move... " + update_time + "： " + filePath);
                try {
					//Path p = Paths.get(filePath);	// 入力ファイルパス
					String fileName =  MyFiles.getFileName(filePath);
                	MyFiles.moveOW(filePath, backupPath + fileName);
                } catch (IOException e) {
                	e.printStackTrace();
                }
            }
        }
	}
}
