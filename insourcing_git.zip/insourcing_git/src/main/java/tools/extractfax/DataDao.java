package tools.extractfax;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class DataDao {
    private final String DB_NAME = "extractfax.db";
    private Connection conn = null;
    private Statement stmt = null;

    public DataDao() {
        try {
            Class.forName("org.sqlite.JDBC");
            this.conn = DriverManager.getConnection("jdbc:sqlite:" + this.DB_NAME);

            this.stmt = conn.createStatement();  
        } catch (Exception e) {
            System.out.println(e);
        }
    }
    
    public ArrayList<DataBean> getDataTable(){
    	String sql = "SELECT NO,FAX_NO,CDATE,CTIME,JOB_NO,FILE_NAME,SOUSHIN_MOTO FROM FAXDATATABLE";
    	
    	ArrayList<DataBean> fax_dao = new ArrayList<DataBean>();
        try {
            ResultSet rs = stmt.executeQuery(sql);
            DataBean fax = null;
            while (rs.next()) {
            	fax = new DataBean(); 
                fax.no = rs.getInt("NO");
                fax.faxNo = rs.getString("FAX_NO");
                fax.cDate = rs.getString("CDATE");
                fax.cTime = rs.getString("CTIME");
                fax.jobNo = rs.getString("JOB_NO");
                fax.fileName = rs.getString("FILE_NAME");
                fax.soushinMoto = rs.getString("SOUSHIN_MOTO");
                fax_dao.add(fax);
            }
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
		return fax_dao;
    }

    public boolean checkFileExist(String fileName){
    	String sql = "SELECT COUNT(FILE_NAME) FROM FAXDATATABLE WHERE FILE_NAME='" + fileName + "'";
        System.out.println(sql);
    
        int count = 0;
    	try {
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                count = rs.getInt("COUNT(FILE_NAME)");
            }
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
		return count!=0?true:false;
    }

	public void insertData(DataBean fax) {
		String sql = "INSERT INTO FAXDATATABLE(FAX_NO,CDATE,CTIME,JOB_NO,FILE_NAME,SOUSHIN_MOTO) "
				   + "VALUES('"+fax.faxNo+"','"+fax.cDate+"','"+fax.cTime+"','"+fax.jobNo+"','"+fax.fileName+"','"+fax.soushinMoto+"')";
        System.out.println(sql);
        try {
            this.stmt.executeUpdate(sql);
        } catch (SQLException e) {
        	System.out.println(e);
        }
	}

	public void deleteWhereDays(String day) {
		String sql = "DELETE FROM FAXDATATABLE WHERE CDATE>'"+day+"'";
        System.out.println(sql);
        try {
            this.stmt.executeUpdate(sql);
        } catch (SQLException e) {
        	System.out.println(e);
        }
	}
}
