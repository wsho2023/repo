package tools.extractfax;

import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

import org.apache.poi.ss.usermodel.Row;

import common.utils.MyExcel;
import common.utils.MyFiles;
import common.utils.MyMail;
import common.utils.MyUtils;

public class ExtractFax {
	static MyMail mailConf;
	static MyExcel xlsx;
	static String xlsPath;
	static String targetPath;
	static String mailBody1;
	static String mailBody2;
	static String xlsSavePath;

	static int allCount;
	static int delCount;
	static void getProperty() throws MissingResourceException {
		ResourceBundle rb = ResourceBundle.getBundle("prop");
        mailConf = new MyMail();
		mailConf.host = rb.getString("MAIL_HOST");
		mailConf.port = rb.getString("MAIL_PORT");
		mailConf.username = rb.getString("MAIL_USER");
		mailConf.password = rb.getString("MAIL_PASS");
		mailConf.smtpAuth = rb.getString("MAIL_SMTP_AUTH");
		mailConf.starttlsEnable = rb.getString("MAIL_SMTP_STARTTLS_ENABLE");

		mailConf.fmAddr = rb.getString("MAIL_FROM");
		mailConf.toAddr = rb.getString("MAIL_USER");
		mailConf.ccAddr = "";
		mailConf.bccAddr = "";

		xlsPath = rb.getString("TARGET_FILE3");
        targetPath = rb.getString("TARGET_PATH3");
		xlsSavePath = rb.getString("SAVE_FILE3");;
	}

	public static void main(String[] args) {
		ArrayList<ArrayList<String>> detList;

    	//-----------------------------------------------------------------
		long elapsed  = System.currentTimeMillis();
		//System.out.println("elapsed: " + elapsed);
    	//-----------------------------------------------------------------
		try {
			getProperty();
		} catch (MissingResourceException e) {
			e.printStackTrace();
			String msg = e.toString();
			MyUtils.SystemErrPrint(msg);
			sendResultMail(msg, null);
			return;
		}
		MyUtils.SystemLogPrint("現在のパス: " + System.getProperty("user.dir"));
        MyUtils.SystemLogPrint("SCANパス: " + targetPath);

    	//-----------------------------------------------------------------
		//Excelオープン
    	//-----------------------------------------------------------------
		xlsx = new MyExcel();
		MyUtils.SystemLogPrint("Excelオープン...:" + xlsPath);
		try {
			xlsx.openXlsm(xlsPath, true);
		} catch (IOException e) {
			e.printStackTrace();
			String msg = e.toString();
			MyUtils.SystemErrPrint(msg);
			sendResultMail(msg, null);
			return;
		}
    	//-----------------------------------------------------------------
		//MAILシート取得
    	//-----------------------------------------------------------------
		xlsx.setSheet("MAIL");
		mailConf.fmAddr = xlsx.getStringCellValue(1, 1);	//配信メール情報:From
		mailConf.toAddr = xlsx.getStringCellValue(2, 1);	//配信メール情報:To
		mailConf.ccAddr = xlsx.getStringCellValue(3, 1);	//配信メール情報:Cc
		mailBody1 = xlsx.getStringCellValue(6, 1);			//配信メール情報:Body1
		mailBody2 = xlsx.getStringCellValue(7, 1);			//配信メール情報:Body2
		mailConf.subject = xlsx.getStringCellValue(5, 1);	//配信メール情報:タイトル
		mailConf.subject = mailConf.subject + "(" + MyUtils.sdf.format(new Date()) + ")";

		//----------------------------------------------------------------------
		//新規FAX(pdf)抽出処理
		//----------------------------------------------------------------------
		allCount = 0;
		delCount = 0;
        detList = scanExtractFile(targetPath);
        if (detList == null) {
			System.err.println("エラーが発生しました。");
		} else if (detList.size() > 1) {
			System.out.println("「" + targetPath + "」フォルダ内のファイルをスキャンしました(スキャン数"+ allCount + " 検出数"+ delCount + ")。");
			//----------------------------------------------------------------------
			//新規FAX(pdf)メール送信処理
			//----------------------------------------------------------------------
			detectSendMail(detList);
		}

        //----------------------------------------------------------------------
		long elapsed2  = System.currentTimeMillis();
		//System.out.println("elapsed: " + elapsed2);
		elapsed = (long)((elapsed2 - elapsed)/1000);
		System.out.println("経過: " + elapsed + " 秒");
		//----------------------------------------------------------------------
	}

	//フィルタを作成する
	static FilenameFilter filter = new FilenameFilter() {
		public boolean accept(File file, String str){
			// 拡張子を指定する
			if (str.endsWith("pdf")){
				return true;
			} else {
				return false;
			}
		}
	};

	static boolean checkFileExist(String fileName, ArrayList<String> faxList) {
    	for (String fax : faxList) {
    		if (fileName.equals(fax) == true) {
    			return true;
    		}
    	}
    	return false;
	}

	static String checkMstExist(String faxNo, ArrayList<ArrayList<String>> mstList) {
    	for (ArrayList<String> mst : mstList) {
    		if (faxNo.equals(mst.get(0)) == true) {
    			return mst.get(1);
    		}
    	}
    	return "";
	}

	private static ArrayList<ArrayList<String>> scanExtractFile(String targetPath) {
		//指定ディレクトリ内のファイルのみ(またはディレクトリのみ)を取得
        File file = new File(targetPath);
        File fileArray[] = file.listFiles(filter);
        if (fileArray == null) {
			String msg = "指定ディレクトリ接続不可";
			MyUtils.SystemErrPrint(msg);
			sendResultMail(msg, null);
			return null;
        }
    	SimpleDateFormat sdfDate = new SimpleDateFormat("yyyy/MM/dd");
    	SimpleDateFormat sdfTime = new SimpleDateFormat("HH:mm:ss");

		//-----------------------------------------------------------------
		// FAXシートを抽出
		//-----------------------------------------------------------------
    	ArrayList<String> faxFilelist = new ArrayList<String>();

		//sheet = (XSSFSheet)xlsx.book.getSheet("FAX");
    	xlsx.setSheet("FAX");
		//https://plus-idea.net/how_to_read_excel_java_apache_poi/#i-2
    	String strValue;
		for (Row row : xlsx.sheet) {
			xlsx.row = row;
			xlsx.getCell(5);	//ファイル名
			strValue = xlsx.getStringCellValue();
			faxFilelist.add(strValue);
		} //for

		//-----------------------------------------------------------------
		// マスタシートを抽出
		//-----------------------------------------------------------------
		//xlsx.setSheet("マスタ");
    	xlsx.setSheet("マスタ");
		//sheet = (XSSFSheet)xlsx.book.getSheet("マスタ");
		//https://plus-idea.net/how_to_read_excel_java_apache_poi/#i-2
    	ArrayList<ArrayList<String>> faxMstlist = new ArrayList<ArrayList<String>>();
    	ArrayList<String> mst = null;
		for (Row row : xlsx.sheet) {
			xlsx.row = row;
			mst = new ArrayList<String>();
			xlsx.getCell(2);	//FAX番号
			strValue = xlsx.getStringCellValue();
			mst.add(strValue);
			xlsx.getCell(3);	//送信元
			strValue = xlsx.getStringCellValue();
			mst.add(strValue);
			faxMstlist.add(mst);
		} //for

		ArrayList<ArrayList<String>> detList = new ArrayList<ArrayList<String>>();
    	ArrayList<String> fax = new ArrayList<String>();
    	//ヘッダNo	FAX番号	date	time	ジョブ番号	ファイル名	送信元	結果
    	fax.add("No");
    	fax.add("FAX番号");
    	fax.add("date");
    	fax.add("time");
    	fax.add("ジョブ番号");
    	fax.add("ファイル名");
    	fax.add("送信元");
    	fax.add("結果");
    	detList.add(fax);

    	boolean existFlag;
    	String fullPath;
        String faxNo, jobNo, sDate, sTime, soushinMoto;
        Long lastModified;
        Date koushin = null;
        for (File f: fileArray) {
    		allCount++;
            //管理表にあるか確認、なければ登録
    		fullPath = f.toString();
            String fileName =  MyFiles.getFileName(fullPath);
            int fileLength = 0;
            existFlag = checkFileExist(fileName, faxFilelist);
            if (existFlag == false) {
            	delCount++;
            	fax = new ArrayList<String>();
            	//---------------------------------------------
            	//管理表へ登録
            	//---------------------------------------------
                fileLength = fileName.length();
                //pdfのファイル名が変更されるとエラーが発生する
                try {
                    faxNo = fileName.substring(3, (fileLength - 14 - 6 - 4)); //(doc + datetimeJOB + 拡張子分(4)分差し引)
                    jobNo = fileName.substring((fileLength-4-6), (fileLength-4)); //(doc + datetimeJOB + 拡張子分(4)分差し引)
                } catch (IndexOutOfBoundsException e) {
                	faxNo = "";
                	jobNo = "";
                }
                lastModified = f.lastModified();
                koushin = new Date(lastModified);	//Dateに変換
                //String update_time = sdfDate.format(koushin);
                sDate = sdfDate.format(koushin);
                sTime = sdfTime.format(koushin);
                //---------------------------------------------
                //FAX送信元 検索
                //---------------------------------------------
                //FAX番号から送信元 検索
                if (faxNo.equals("")==false) {
                	soushinMoto = checkMstExist(faxNo, faxMstlist);
                } else {
                	soushinMoto = "";
                }

                //---------------------------------------------
                //書き出し
                //---------------------------------------------
            	fax = new ArrayList<String>();
            	//ヘッダNo	FAX番号	date	time	ジョブ番号	ファイル名	送信元	結果
            	fax.add("");
            	fax.add(faxNo);
            	fax.add(sDate);
            	fax.add(sTime);
            	fax.add(jobNo);
            	fax.add(fileName);
            	fax.add(soushinMoto);
            	fax.add("");
            	detList.add(fax);
            	//'ハイパーリンクはサーバ上だと警告が出るので廃止→マクロでファイルを開くように変更
            	//strFullPath = currentPath & pdf
            	//'detectSheet.Hyperlinks.Add Anchor:=Range("F" & GYO), Address:="", ScreenTip:=strFullPath, TextToDisplay:=pdf    '表示はファイル名、リンクはフルパス
            }
        }
    	String detectFilePath = ".\\detect.tsv";
    	try {
			MyFiles.existsDelete(detectFilePath);	//存在を確認し、あればファイル削除
		} catch (IOException e) {
			e.printStackTrace();
			String msg = e.toString();
			MyUtils.SystemErrPrint(msg);
			sendResultMail(msg, null);
			return null;
		}
        if (detList.size() > 1) {
            //---------------------------------------------
        	//管理表更新
        	//---------------------------------------------
        	try {
				MyFiles.writeList2File(detList, detectFilePath, "SJIS");
			} catch (IOException e) {
				e.printStackTrace();
				String msg = e.toString();
				MyUtils.SystemErrPrint(msg);
				sendResultMail(msg, null);
				return null;
			}

    		System.out.println("■scanProcess: start... 取込開始");
    	    //------------------------------------------------------
    	    //取り込み実行
    	    //------------------------------------------------------
        	//------------------------------------------------------
        	//Javaで実施
        	//------------------------------------------------------
    		saveDetList(detList);

        	//------------------------------------------------------
        	//VBAで実施
        	//------------------------------------------------------
    		//https://blog.goo.ne.jp/xmldtp/e/beb03fb01fb1d1a2c37db8d69b43dcdd
    		//コマンドラインから****.vbsを呼び出せる。
    		String[] cmdList = new String[4];
    		cmdList[0] = "cscript";
    		cmdList[1] = "extractFax.vbs";		//VBSファイル指定
    		cmdList[2] = "/file:extractFax.xlsm";
    		cmdList[3] = "/method:FAX抽出";
    		try {
    		    MyUtils.exeCmd(cmdList);
    		} catch (IOException e) {
    			e.printStackTrace();
    			String msg = e.toString();
    			MyUtils.SystemErrPrint(msg);
    			sendResultMail(msg, null);
    			return null;
    		} catch (InterruptedException e) {
    			e.printStackTrace();
    			String msg = e.toString();
    			MyUtils.SystemErrPrint(msg);
    			sendResultMail(msg, null);
    			return null;
    		}
        }

    	return detList;
	}

	static void detectSendMail(ArrayList<ArrayList<String>> detList) {
//    	String detectFilePath = ".\\detect.tsv";
//    	ArrayList<ArrayList<String>> list = null;
//    	try {
//    		list = MyFiles.parseTSV(detectFilePath, "SJIS");
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
    	String strPdfList = "";
    	if (detList.size()>1) {
    		//下のからリストアップ
        	for (int r=(detList.size()-1); r>0; r--) {
        		strPdfList = strPdfList + detList.get(r).get(5) + "\n";	// F列：ファイル名を抽出
        	}
    		mailConf.body = mailBody1 + "\n"
    					  + strPdfList
    					  + mailBody2 + "\n";
    		System.out.println("メール送信...");
    		System.out.println("MAIL FmAddr: " + mailConf.fmAddr);
    		System.out.println("MAIL ToAddr: " + mailConf.toAddr);
    		System.out.println("MAIL CcAddr: " + mailConf.ccAddr);
    		System.out.println("MAIL BcAddr: " + mailConf.bccAddr);
    		System.out.println("MAIL Subject: " + mailConf.subject);
    		System.out.println("MAIL Body: \n" + mailConf.body);
    		System.out.println("MAIL Attach: " + mailConf.attach);
        	//mailConf.sendRawMail();
    	}
	}

	private static void saveDetList(ArrayList<ArrayList<String>> detList) {
		MyExcel xlsx = new MyExcel();
		try {
			xlsx.openOW(xlsSavePath, "FAX");
		} catch (IOException e) {
			e.printStackTrace();
			String msg = e.toString();
			MyUtils.SystemErrPrint(msg);
			sendResultMail(msg, null);
			return;
		}

		int maxRow = detList.size();
		int maxCol;
		String strValue;
		//xlsx.setSheet("FAX");
		int lastRow = xlsx.sheet.getLastRowNum();
		int rowIdx = lastRow + 1;	//書き込み行＝末尾行＋１
		System.out.println("書き込み開始位置: " + rowIdx);
		//1行目はヘッダのなので除去
		for (int Idx=0; Idx<maxRow; Idx++) {
			xlsx.createRow(rowIdx);			//行の生成
			maxCol = detList.get(Idx).size();
			for (int colIdx=0; colIdx<maxCol; colIdx++) {
				if (colIdx != 0)
					strValue = detList.get(Idx).get(colIdx);
				else
					strValue = Integer.valueOf(rowIdx).toString();
				xlsx.setCellValue(colIdx, strValue);
			}
			rowIdx++;
		}
		System.out.println("書き込み終了位置: " + (rowIdx-1));
		//末尾行をアクティブセルにする。
		if (xlsx.getRow(rowIdx-1)) {
			xlsx.setAsActiveCell(0);
		}

		//------------------------------------------------------
		//削除対応
		//------------------------------------------------------
		//Cell cell;
		xlsx.setSheet("FAX");
		for (Row row : xlsx.sheet) {
			xlsx.row = row;
			xlsx.getCell(1);	//日付
			strValue = xlsx.getStringCellValue();

			//https://qiita.com/fumikomatsu/items/b98cc4d0dee782323096
        	// 現在日時を取得
            Calendar st = Calendar.getInstance();	//Calendarクラスで現在日時を取得
            st.add(Calendar.DATE, -365);			//現在値を取得(365日前)
            Date start = st.getTime();           	//Dateに変換
            // yyyy/MM/ddをDate型に変換
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
            Date koushin;
			try {
				koushin = dateFormat.parse(strValue);	//Dateに変換
	            if (start.compareTo(koushin) > 0) {		//compareToで比較
	            	xlsx.sheet.removeRow(xlsx.row);		//その行をdelete処理
	        		delCount++;
	            }
			} catch (ParseException e) {
				e.printStackTrace();
				String msg = e.toString();
				MyUtils.SystemErrPrint(msg);
				sendResultMail(msg, null);
				return;
			}
        }

		// 上書き保存
		try {
			xlsx.saveOW(xlsPath);
		} catch (IOException e) {
			e.printStackTrace();
			String msg = e.toString();
			MyUtils.SystemErrPrint(msg);
			sendResultMail(msg, null);
			return;
		}
	}

	private static void sendResultMail(String msg, String attachFilePath) {
		String dateStr = MyUtils.getDateStrDateFormat(0, "yyyy/MM/dd HH:mm:ss");
		if (msg.equals("正常終了") == true)
			mailConf.subject = "[]完了連絡("+dateStr+")";
		else
			mailConf.subject = "[]エラー連絡("+dateStr+")";
		mailConf.body = msg + "\n";
		mailConf.attach = attachFilePath;
		MyUtils.SystemLogPrint("  メール送信...");
		MyUtils.SystemLogPrint("  MAIL FmAddr: " + mailConf.fmAddr);
		MyUtils.SystemLogPrint("  MAIL ToAddr: " + mailConf.toAddr);
		MyUtils.SystemLogPrint("  MAIL CcAddr: " + mailConf.ccAddr);
		MyUtils.SystemLogPrint("  MAIL BcAddr: " + mailConf.bccAddr);
		MyUtils.SystemLogPrint("  MAIL Subject: " + mailConf.subject);
		MyUtils.SystemLogPrint("  MAIL Body: \n" + mailConf.body);
		MyUtils.SystemLogPrint("  MAIL Attach: " + mailConf.attach);
    	mailConf.sendRawMail();
	}
}
