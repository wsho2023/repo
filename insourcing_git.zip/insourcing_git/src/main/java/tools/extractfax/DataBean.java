package tools.extractfax;

public class DataBean {
	public int no;
	public String faxNo;
	public String cDate;
	public String cTime;
	public String jobNo;
	public String fileName;
	public String soushinMoto;
}
