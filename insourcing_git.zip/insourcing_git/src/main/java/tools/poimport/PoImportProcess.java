package tools.poimport;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;

import common.po.PoErrlBean;
import common.po.PoErrlDAO;
import common.po.PoUploadBean;
import common.po.PoUploadDAO;
import common.utils.MyDBInfo;
import common.utils.MyExcel;
import common.utils.MyFiles;
import common.utils.MyMail;
import common.utils.MyUtils;

public class PoImportProcess {
	static MyDBInfo dBInfo;
	static MyMail mailConf;
	static boolean TEST_FLAG;

	static void getProperty() throws MissingResourceException {
		ResourceBundle rb = ResourceBundle.getBundle("prop");
		dBInfo = new MyDBInfo(
				rb.getString("DB_URL"),
				rb.getString("DB_USER"),
				rb.getString("DB_PASS"),
				rb.getString("DB_DRIVER"));
		dBInfo.USER = "TEST1";
		dBInfo.PASS = "TEST1";
		mailConf = new MyMail();
		mailConf.host = rb.getString("MAIL_HOST");
		mailConf.port = rb.getString("MAIL_PORT");
		mailConf.username = rb.getString("MAIL_USER");
		mailConf.password = rb.getString("MAIL_PASS");
		mailConf.smtpAuth = rb.getString("MAIL_SMTP_AUTH");
		mailConf.starttlsEnable = rb.getString("MAIL_SMTP_STARTTLS_ENABLE");

		mailConf.fmAddr = rb.getString("MAIL_FROM");
		mailConf.ccAddr = "";
		mailConf.bccAddr = mailConf.fmAddr;

		TEST_FLAG = false;
	}

	public static void main(String[] args) {
		if (args.length != 1) {
		    System.out.println("引数を1つ指定して下さい");
		    System.exit(1);
		}

		System.out.println("args[0]: " + args[0]);
		String uploadFilePath = args[0];
		String uploadFilePath2;
		if (uploadFilePath.contains("done\\")) {
			uploadFilePath2 = uploadFilePath.replace("done\\", "");
			dBInfo.USER = "TEST1";
			dBInfo.PASS = "TEST1";
			TEST_FLAG = true;
		} else
			uploadFilePath2 = uploadFilePath;

		MyUtils.SystemLogPrint("■PoImportProcess: start... ");
		//------------------------------------------------------
		long elapsed  = System.currentTimeMillis();
		//System.out.println("elapsed: " + elapsed);
		//------------------------------------------------------
		try {
			getProperty();
		} catch (MissingResourceException e) {
			e.printStackTrace();
			String msg = e.toString();
			MyUtils.SystemErrPrint(msg);
			//sendResultMail(msg, null);
			return;
		}
		MyUtils.SystemLogPrint("現在のパス: " + System.getProperty("user.dir"));

	    //------------------------------------------------------
		//アップロード情報の取得
	    //------------------------------------------------------
		PoUploadBean upload = getUploadInfo(uploadFilePath2);
		if (upload == null || upload.getUserId().equals("")==true) {
			String msg = "upload情報を取得できませんでした。";
			MyUtils.SystemErrPrint(msg);

			mailConf.toAddr = mailConf.fmAddr;
			String createdAt = MyUtils.getDateStrDateFormat(0, "yyyy/MM/dd HH:mm:ss");
			mailConf.subject = "登録エラー連絡(" + createdAt + ")";
			mailConf.body = "------------------------------------------------\n"
						  + "登録日時: " + createdAt + "\n"
						  + "ファイル  : " + uploadFilePath + "\n"
						  + "内容   : " + msg + "\n"
						  + "------------------------------------------------\n";
			mailConf.attach = uploadFilePath;
			sendAttachMail();
			return;
		}

	    //------------------------------------------------------
	    //取り込み実行
	    //------------------------------------------------------
		importData(upload, uploadFilePath);

		//------------------------------------------------------
		long elapsed2  = System.currentTimeMillis();
		//System.out.println("elapsed: " + elapsed2);
		elapsed = (long)((elapsed2 - elapsed)/1000);
		MyUtils.SystemLogPrint("■PoImportProcess: end... 経過: " + elapsed + " 秒");
		//------------------------------------------------------
	}

	private static int importData(PoUploadBean upload, String importFilePath) {
		if (MyFiles.exists(importFilePath) != true) {
			String msg = "インポート用ファイルが見つかりませでんした。システム管理者に確認してください。";
			MyUtils.SystemErrPrint(msg);

			mailConf.toAddr = upload.getUserId();
			mailConf.subject = "登録エラー連絡(" + upload.getToriCd() + " " + upload.getDatetime() + ")";
			mailConf.body = "------------------------------------------------\n"
						  + "取引先CD: " + upload.getToriCd() + "\n"
						  + "登録日時: " + upload.getDatetime() + "\n"
						  + "ファイル  : " + importFilePath + "\n"
						  + "内容   : " + msg + "\n"
						  + "------------------------------------------------\n";
			mailConf.attach = importFilePath;
			sendAttachMail();
			return -1;
		}

		//取込ファイルの読込み
		ArrayList<ArrayList<String>> readList = getImportFileData(importFilePath);
		//特定の取込ファイルの加工
		if (upload.getToriCd().equals("H2576") == true ) {
			boolean detect = false;
			for (int r=0; r<readList.size(); r++) {
				detect = false;
				//①"発注番号"を検索、その行を取得
				//②その行より、上の行全部を削除して、①の行を先頭にする。
				//③or "発注番号"のある行をヘッダとして、それ以降のみを取り込む
				for (String value : readList.get(r)) {
					if (value.equals("発注番号")) {
						detect = true;
					}
				}
				//検出なし → 当該行は削除
				if (detect != true) {
					readList.remove(r);
					r--;
				} else {
					//削除せず、ループ抜ける
					break;
				}
			}
		}

		//◆2023/05/31: 
		if (upload.getToriCd().startsWith("A6345")==true) {
			upload.setToriCd("A6345");
		}
	    ArrayList<String> convList = null;
		try {
			convList = getConvList(upload.getToriCd());
		} catch (IOException e) {
			e.printStackTrace();
		}
	    if (convList == null) {
	    	String msg = "種別が見つかりませでんした。システム管理者に確認してください。";
			MyUtils.SystemErrPrint(msg);

			mailConf.toAddr = upload.getUserId();
			mailConf.subject = "登録エラー連絡(" + upload.getToriCd() + " " + upload.getDatetime() + ")";
			mailConf.body = "------------------------------------------------\n"
						  + "取引先CD: " + upload.getToriCd() + "\n"
						  + "登録日時: " + upload.getDatetime() + "\n"
						  + "ファイル  : " + importFilePath + "\n"
						  + "内容   : " + msg + "\n"
						  + "------------------------------------------------\n";
			mailConf.attach = importFilePath;
			sendAttachMail();
			return -1;
	    }

		//列 変換 処理
		ArrayList<PoImportBean> outputList = new ArrayList<PoImportBean>();
        //◆2021/09/30:
		if (upload.getToriCd().equals("K8495")||upload.getToriCd().equals("K8530")) {
			//    bunoNum = dataNum
			//    dataNum = 1
		}
		PoImportDAO dao = new PoImportDAO(dBInfo);
	    //-----------------------------------------------
	    //ベース注文データの注文No取得（DB update版の時のみ使用）
	    //-----------------------------------------------
	    //◆2021/10/19:
	    String base;
	    if (upload.getToriCd().equals("K8495")||upload.getToriCd().equals("K8530")) {
	        base = "ZZZZ2";
	    } else {
	        base = "Z9999";
	    }
	    int count = dao.getCountChumonNo(base);
	    if (count<=100) {
			MyUtils.SystemErrPrint("ベース注文が１００件以下です。追加してください。");

			mailConf.toAddr = mailConf.fmAddr;
			mailConf.subject = "登録ワーニング連絡(" + upload.getToriCd() + " " + upload.getDatetime() + ")";
			mailConf.body = "------------------------------------------------\n"
						  + "取引先CD: " + upload.getToriCd() + "\n"
						  + "登録日時: " + upload.getDatetime() + "\n"
						  + "残数    : " + count + "\n"
						  + "ベース注文が１００件以下です。追加してください。\n"
						  + "------------------------------------------------\n";
			mailConf.attach = "";
			sendAttachMail();
			return -1;
	    }
	    ArrayList<String> chumonNoList = dao.getBaseChumonNo(base, readList.size());
	    if (chumonNoList == null) {
	    	//内部エラー
	    	return -1;
	    }

	    String toriCd = upload.getToriCd();
	    int readCol;
	    String strValue;
	    int youkyuDateCnt = 0;
	    int youkyuSuryoCnt = 0;
	    int kibouDateCnt = 0;
	    int kibouSuryoCnt = 0;
	    for (int r=1; r<readList.size(); r++) {
		    PoImportBean poImp = new PoImportBean();
	    	for (int c=0; c<convList.size(); c++) {
		    	strValue = convList.get(c);
		    	if (strValue.equals("")!=true) {
		    		try {
		    			readCol = Integer.parseInt(strValue);	//strValue=convList.get(c)
		    			strValue = readList.get(r).get(readCol);
		    			if (strValue.equals("0")!=true) {		//◆2020/03/06: 値が0の時は入力しない（空白）
		    				strValue = "";
		    				//poImp.xxxxx = strValue;
			    		}
		    		} catch(NumberFormatException e) {
		    			// 固定値が入っているケース
		    			readCol = 0;
		    		}
			    	if (c == 1) {				//A:営業所
		    			poImp.eigyoSho = strValue.substring(5, 8);
			    	} else if (c == 2) {		//B:営業組織
		    			poImp.eigyoSoshiki = strValue.substring(6, 14);
			    	} else if (c == 3) {		//C:担当者
		    			poImp.tantoshaCd = strValue;
			    	} else if (c == 4) {		//D:集計ｺｰﾄﾞ
			    		//upload情報を入れる。
		    			poImp.shukeiCd = upload.getCode();
			    	} else if (c == 5) {		//E:新作リピート
		    			//固定値を入れる。
		    			poImp.shinsakuRepeat = convList.get(c);
			    	} else if (c == 87) {		//製伝区分
			    		if (toriCd.equals("EXCEL")) {
		    				//読み込みデータから、製伝区分抽出
		    				readCol = Integer.parseInt(convList.get(c));
		    				poImp.seidenKbn = readList.get(r).get(readCol); 
			    		} else {
			    			//変換リストから抽出
			    			poImp.seidenKbn = convList.get(c);
			    		}
		    			if (poImp.seidenKbn.equals("E")!=true)
		    				poImp.seidenKbn = "K";
			    	} else if (c == 6) {		//F列:取引先
			    		//固定値のケース
			    		//if (convList.get(c).length() == 5 ) {
			    		//	//strValueは変換されずに 固定値が入っているはず!
			    		//}
			    		poImp.toriCd = strValue;
			    	} else if (c == 7) {		//PN
			    		//◆2021/09/30: 
			    		if (toriCd.equals("K8495")||toriCd.equals("K8530")) {
			    			strValue = readList.get(2).get(readCol);	//2行目
			    			strValue = strValue.substring(2, 15);	//3桁目から12桁取得)
			    		}
			    		//◆2021/10/13: S9774 PN,図番は、( 以下は出力しない
			    		if (toriCd.equals("S9774")) {
			    			int start = strValue.indexOf("(");
			    			if (start > 0) {
			    				int len = strValue.length();
			    				strValue = strValue.substring(0, (len-start));	//(len-start)でよいか要調整
			    			}
			    		}
			    		poImp.kyakuPn = strValue;
			    	} else if (c == 8) {		//PO
			    		if (toriCd.equals("S7868")) {
			    			//右から５桁目に空白を入れて登録
			    			int len = strValue.length();
			    			strValue = strValue.substring(0, (len-5)) + " " + strValue.substring((len-5), len);
			    		}
			    		poImp.chuban = strValue;
			    	} else if (c == 9) {		//数量
			    		if (toriCd.equals("K8495")||toriCd.equals("K8530")) {
			    			//明細の全合計を数量として 入れること
			    			int suryo = 0;
			    			for (int r2=1; r2<readList.size(); r2++) {
			    				suryo = suryo + Integer.parseInt(readList.get(r2).get(readCol+1));
			    			}
			    			strValue = String.valueOf(suryo);
			    		}
			    		poImp.suryo = strValue;
			    	} else if (c == 10) {		//単価
			    		poImp.tanka = strValue;
			    	} else if (c == 11) {		//型代
			    		poImp.katadai = strValue;
			    		if (poImp.katadai.equals("")) {
			    			poImp.katadai = "0";
			    		}
			    	} else if (c == 12) {		//事業部
			    		poImp.jigyobuCd = strValue;
			    	} else if (c == 13) {
			    		//なし
			    	} else if (c == 14) {		//事業所
			    		poImp.jigyoSho = strValue;
			    	} else if (c == 15) {		//加工部門
			    		poImp.kakoCd = strValue;
			    	} else if (c == 16) {		//図番
			    		//◆2021/10/13: S9774 PN,図番は、( 以下は出力しない
			    		if (toriCd.equals("S9774")) {
			    			int start = strValue.indexOf("(");
			    			if (start > 0) {
			    				int len = strValue.length();
			    				strValue = strValue.substring(0, (len-start));	//(len-start)でよいか要調整
			    			}
			    		}
			    		poImp.zuban = strValue;
			    	} else if (c == 17) {		//SPEC
			    		poImp.spec = strValue;
			    	} else if (c == 18) {
			    	} else if (c == 71) {		//品名1
			    		poImp.hinmei1 = strValue;
			    	} else if (c == 72) {		//品名2
			    		poImp.hinmei2 = strValue;
			    	} else if (c == 74) {		//品種1
			    		poImp.hinshu1Cd = strValue;
			    	} else if (c == 75) {		//品種2
			    		poImp.hinshu2Cd = strValue;
			    	} else if (c == 76) {		//材質
			    		poImp.zaishitsuCd = strValue;
			    	} else if (c == 78) {		//依頼先部門
			    		poImp.iraisakiKakoCd = strValue;
			    	} else if (c == 79) {		//依頼先事業所
			    		poImp.iraisakiJigyosSho = strValue;
			    	} else if (c == 61||c == 64||c == 65||c == 67||c == 69||
			    			   c == 127||c ==136||c == 145||c == 154||c == 163) {
						//受注予定月
						if (toriCd.equals("K8495")||toriCd.equals("K8530")) {

						} else {

						}
						int len = strValue.length();
						if (len == 10) {
							//yyyy/MM/dd から/ddを切ってyyyMM
							strValue = strValue.substring(0,4) + strValue.substring(5,7); 
						} else if (len == 8) {
							if (strValue.indexOf("/") > 0) {
								//yy/MM/dd → 20yyMM
								strValue = "20" + strValue.substring(0,2) + strValue.substring(3,5);
							} else {
								//yyyyMM/dd → yyyyMM
								strValue = strValue.substring(0,6);
							}
						} else if (len == 6) {
							//yyMMdd → 20yyMM
							strValue = "20" + strValue.substring(0,4);	//先頭20を補填
						} else {
							//どれ当てはまらない → 本日から算出して、yyyyMM
							strValue = MyUtils.getDateStrDateFormat(0, "yyyyMM");							
						}
						//◆2021/09/28: C2748
						if (toriCd.equals("C2748")==true) {
							strValue = MyUtils.getDateStrDateFormat(0, "yyyyMM");
						}
						if (toriCd.equals("H0005")||toriCd.equals("EXCEL") ) {
							int year = Integer.parseInt(strValue.substring(0,4));
							int month = Integer.parseInt(strValue.substring(4,6));
							if (month > 2) {
								month = month - 2; //-2カ月
							} else {
								year = year - 1;
								month = month + 12 - 2; //-2カ月
							}
							strValue = String.valueOf(year)+String.valueOf(month);
						} else if (toriCd.equals("S7188")||toriCd.equals("E2193")) {
							int year = Integer.parseInt(strValue.substring(0,4));
							int month = Integer.parseInt(strValue.substring(4,6));
							if (month > 1) {
								month = month - 1; //-1カ月
							} else {
								year = year - 1;
								month = month + 12 - 1; //-1カ月
							}
							strValue = String.valueOf(year)+String.valueOf(month);
						}
						if (toriCd.equals("K8495")||toriCd.equals("K8530")) {

						} else {
							poImp.meisaiList.get(0).yoteiMonth = strValue;
						}
					} else if (c == 62||c == 64||c == 66||c == 67||c == 70||
		    			   c == 128||c ==137||c == 146||c == 155||c == 164) {
						//受注予定月 数量
						if (upload.getToriCd().equals("K8495")||upload.getToriCd().equals("K8530")) {

						}
						poImp.meisaiList.get(0).yoteiSuryo = strValue;
			    	} else if ((20 <= c && c <= 50) || (451 <= c && c <= 738)) { //納期は、"/"不要→一律"/"削除
			    		strValue = strValue.replaceAll("/", "");	//yyyy/MM/dd
			    		strValue = strValue.replaceAll("-", "");	//yyyy-MM-dd
			    		if (strValue.length() > 8) {
			    			strValue = strValue.substring(0,8);		//8桁超入ってる場合は、ゴミなので削除
			    		}
						if (upload.getToriCd().equals("K8495")||upload.getToriCd().equals("K8530")) {
							//客要納期
						} else {
							//客要納期
							if (c == 20||c == 22||c == 24||c == 26||c == 28) {
								poImp.noukiList.get(youkyuDateCnt).youkyuDate = strValue;
								youkyuDateCnt++;
							}
							//客要数量
							if (c == 21||c == 23||c == 25||c == 27||c == 29) {
								poImp.noukiList.get(youkyuSuryoCnt).youkyuSuryo = strValue;
								youkyuSuryoCnt++;
							}
							//希望納期
							if (c == 30||c == 32||c == 34||c == 36||c == 38) {
								poImp.noukiList.get(kibouDateCnt).kibouDate = strValue;
								kibouDateCnt++;
							}
							//希望数量
							if (c == 31||c == 33||c == 35||c == 37||c == 39) {
								poImp.noukiList.get(kibouSuryoCnt).kibouSuryo = strValue;
								kibouSuryoCnt++;
							}
						}
			    	}
		    	}
		    }
	    	//注文NO取得
	    	poImp.chumonNo = chumonNoList.get(r);
			//最新製伝No取得
	    	poImp.refSeidenNo = dao.getRefSeidenNo(poImp.toriCd, poImp.kyakuPn);

			outputList.add(poImp);
	    }

	    ArrayList<String> sqlList = new ArrayList<String>();
	    String chubanList = "";
	    PoImportBean poImp;
	    String sql = "";
	    for (int o=outputList.size(); o>0; o-- ) {	// 最下行から上の順番に登録処理をする。一番上が最も新しくなるはず
	    	poImp = outputList.get(o);
	    	chubanList = chubanList + poImp.chuban + "\n";
	    	if (poImp.katadai.equals("")) {
	    		poImp.katadai = "0";
	    	}
	    	poImp.renrakuMemo = "";
	    	if (toriCd.equals("H0005")) {	//◆2021/09/08: 
	    		poImp.noteRan = poImp.hinmei1;
	    	} else if (toriCd.equals("K6723")) {	//◆2021/09/14:
	    		if (poImp.sofuCd.equals("4"))
	    			poImp.sofuCd = "04";
	    		if (poImp.sofuCd.equals("")!=true)
	    	    	poImp.noteRan = poImp.sofuCd;
	    		else
	    			poImp.noteRan = "";
	    	} else if (toriCd.equals("T1302")) {	//◆2021/09/14:
	    		if (poImp.sofuCd.equals("TMC1"))
	    			poImp.sofuCd = "TMC1R";
	    		if (poImp.sofuCd.equals("")!=true)
	    	    	poImp.noteRan = poImp.sofuCd;
	    		else
	    			poImp.noteRan = "";
	    	} else
				poImp.noteRan = "";

	    	//if (toriCd.equals("E3035")||toriCd.equals("E3036"))	//◆2023/09/07: 
	    		//poImp.noteRan = poImp.eigyoMemo;

	    	//-----------------------------------------------
	    	//注文ヘッダ
	    	//-----------------------------------------------
	    	sql = dao.makeChumonSql(poImp);
	    	sqlList.add(sql);

	    	//-----------------------------------------------
	    	//注文明細
	    	//-----------------------------------------------
	    	Double dblSuryo = 0.0;
	    	Double dblTanka = 0.0;
	    	int intKingaku = 0;
	    	try {
	    		dblSuryo = Double.parseDouble(poImp.suryo);
	    		dblTanka = Double.parseDouble(poImp.tanka);
	    		intKingaku = (int)(dblSuryo*dblTanka);
	    		poImp.meisaiList.get(0).kingaku = String.valueOf(intKingaku);
	    	} catch(NumberFormatException e) {
	    		//数量/単価が数値じゃないケースはエラーにしないといけない
	    		poImp.meisaiList.get(0).kingaku = "エラー";
	    	}
	    	sql = dao.makeMeisaiSql(poImp, 0);
	    	sqlList.add(sql);
	    	//◆2021/10/19:
	    	if (upload.getToriCd().equals("K8495")||upload.getToriCd().equals("K8530")) {
	    		//-----------------------------------------------
	    		//2以降はループ
	    		//-----------------------------------------------
	    		for (int meisaiNo=1; meisaiNo<=30; meisaiNo++) {
	    	    	sql = dao.makeMeisaiSql(poImp, meisaiNo);
	    	    	if (sql != null)
	    	    		sqlList.add(sql);
	    		}
	    	}

	    	//-----------------------------------------------
	    	//分納
	    	//-----------------------------------------------
    		String youkyuDate;
    		String kibouDate;
	    	for (int n=0; n<poImp.noukiList.size(); n++) {
	    		youkyuDate = poImp.noukiList.get(n).youkyuDate;
	    		kibouDate = poImp.noukiList.get(n).kibouDate;
		    	if (toriCd.equals("H0005") && kibouDate.equals("")!=true) {	//◆2021/09/13: H0005
		    		kibouDate = DataAdd(kibouDate, -7);
		    	}
		    	if (toriCd.equals("S7188") && kibouDate.equals("")!=true) {	//◆2021/11/02: S7188
		    		kibouDate = DataAdd(kibouDate, -7);
		    	}
		    	if ((toriCd.equals("F0532")||toriCd.equals("T0920")||toriCd.equals("E3035")||toriCd.equals("E3036")) && kibouDate.equals("")!=true) {	//◆2021/11/02: S7188
		    		kibouDate = DataAdd(kibouDate, -7);
		    	}
		    	if (toriCd.equals("E2193") && kibouDate.equals("")!=true) {	//◆2021/11/26: E2193
		    		kibouDate = DataAdd(kibouDate, -21);
		    	}
		    	if (toriCd.equals("E2192") && kibouDate.equals("")!=true) {	//◆2021/11/26: E2192
		    		kibouDate = DataAdd(kibouDate, -10);
		    	}
		    	if (toriCd.equals("K6723") && kibouDate.equals("")!=true) {	//◆2021/09/15: K6723
		    		if (poImp.sofuCd.equals("KMM")) 
		    			kibouDate = DataAdd(kibouDate, -2);
		    		else if (poImp.sofuCd.equals("04"))
		    			kibouDate = DataAdd(kibouDate, -3);
		    	}
		    	if (toriCd.equals("T1302") && kibouDate.equals("")!=true) {	//◆2021/09/15: T1302
		    		if (poImp.sofuCd.equals("TMC1R")) 
		    			kibouDate = DataAdd(kibouDate, -2);
		    		else if (poImp.sofuCd.equals("TEW4"))
		    			kibouDate = DataAdd(kibouDate, -3);
		    	}
		    	if (toriCd.equals("C2748") == true) {	//◆2024/05/18: C2748
		    		youkyuDate = "";
		    		kibouDate = "";
		    	}
		    	//製造ﾒﾓへの入力（K6723のみ）
		    	if (toriCd.equals("K6723") == true) {
		    		if (poImp.sofuCd.equals("KMM")) 
		    			poImp.renrakuMemo = "金沢向け";
		    		else if (poImp.sofuCd.equals("04"))
		    			poImp.renrakuMemo = "仙台向け";
		    	}
		    	// 客要納期 および 希望納期のどちらが入っていれば実行 
		    	if (kibouDate.equals("")!=true || youkyuDate.equals("")!=true) {
		    		poImp.noukiList.get(n).youkyuDate = youkyuDate;
		    		poImp.noukiList.get(n).kibouDate = kibouDate;
			    	sql = dao.makeBunouSql(poImp, n);
			    	sqlList.add(sql);
		    	}
	    	}
	    }
	    //-----------------------------------------------
	    //SQL作成開始(declare begin ～ end;)
	    //-----------------------------------------------
	    sql = "declare begin ";
	    for (int i=0; i<sqlList.size(); i++) {
	    	sql = sql + sqlList.get(i);
	    }
    	sql = sql + "end;";
	    dao.executeUpdate(sql);

	    //-----------------------------------------------
	    //保存
	    //-----------------------------------------------

	    //-----------------------------------------------
	    //完了メール連絡
	    //-----------------------------------------------
		mailConf.toAddr = upload.getUserId();
	    //タイトル
	    if (TEST_FLAG == false)
	    	mailConf.subject = "完了連絡("+upload.getToriCd()+" "+upload.getDatetime()+")";
	    else {
	    	mailConf.subject = "完了連絡("+upload.getToriCd()+" "+upload.getDatetime()+")(ﾃｽﾄ環境)";
	    	mailConf.toAddr = mailConf.fmAddr;
	    }
	    mailConf.body = "-------------------------------\n"
	    			  + "取引先CD: " + upload.getToriCd() + "\n"
					  + "登録日時: " + upload.getDatetime() + "\n"
					  + "件数    : " + outputList.size() + "\n"
					  + "備考    : ***********************\n"
	    			  + "-------------------------------";
	    mailConf.attach = importFilePath;
	    sendAttachMail();

	    //メール送信第2弾
	    if (upload.getToriCd().equals("ZZZZZ") != true) {
	    	mailConf.fmAddr = "test1@gmail.com";
			mailConf.toAddr = "test2@gmail.com";
			mailConf.ccAddr = "";
			mailConf.bccAddr = mailConf.fmAddr;
		    //タイトル
			String toriMei = dao.getToriMei(upload.getToriCd());
			mailConf.toAddr = "ｱｯﾌﾟﾛｰﾄﾞ("+upload.getDatetime()+" "+toriMei+"/"+upload.getToriCd();
			mailConf.body = "ヘッダ\n" + chubanList;
			String inputPath = upload.getInputPath();
			if (inputPath.equals("NO-OCR") == true)
				mailConf.attach = importFilePath;
			else
				mailConf.attach = inputPath;
		    sendAttachMail();

		    //DB登録
		    String fileName = MyFiles.getFileName(mailConf.attach);
		    String uniqId = fileName.substring(0, 20);
		    String poList = chubanList.replaceAll("\n", " ");	//trimも
		    PoErrlBean errl = new PoErrlBean();
        	errl.setErrlData(uniqId, upload.getUserName(), toriMei, poList, mailConf.subject, 0, mailConf.attach);
        	PoErrlDAO.getInstance(dBInfo).insertDB(errl);
	    }

		return 0;
	}

	private static String DataAdd(String strDate, int days) {
		//srtDate:yyyyMMdd 8桁であることを確認して、Date(yyyyMMdd)にして、daysを加算
		if (strDate.length() != 8)
			return null;

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
        // yyyy/MM/ddへ変更
        strDate = strDate.substring(0, 4) + "/" + strDate.substring(4, 6) + "/" + strDate.substring(6, 8);

        // Date型に変換
        Date date;
		try {
			date = sdf.parse(strDate);
		} catch (ParseException e) {
			e.printStackTrace();
			return null;
		}

	    // Date型の日時をCalendar型に変換
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        // 日(Calendar.DATE)を加算する
        calendar.add(Calendar.DATE, days);

        // Calendar型の日時をDate型に戻す
        Date date2 = calendar.getTime();

        return sdf.format(date2);
	}

	private static PoUploadBean getUploadInfo(String uploadFilePath) {
		PoUploadBean upload = null;
		int retryCnt = 0;
		for (;;) {
			upload = PoUploadDAO.getInstance(dBInfo).quertyWithUploadPath(uploadFilePath);	//こちらは、quertyWithInputPathを使う
			if (upload != null) {
				//取得
				MyUtils.SystemLogPrint("  userId: " +  upload.getUserId() + "  datetime: " + upload.getDatetime() + "  toriCd: " + upload.getToriCd() + "  code: " + upload.getCode() + "  inputPath: " + upload.getInputPath());
				break;
			}
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			//取得データがまだないときがありリトライを追加
			retryCnt++;
			if (retryCnt > 10) {
				MyUtils.SystemErrPrint("アップロード情報を取得できませんでした。処理を中止します。");
				return null;
			}
		}

		return upload;
	}

	private static ArrayList<ArrayList<String>> getImportFileData(String importFilePath) {
		ArrayList<ArrayList<String>> readList = null;
		if (importFilePath.endsWith("xlsx")) {
			//Excel読込
	    	try {
	    		MyExcel xlsx = new MyExcel();
	    		readList = xlsx.readDataList(importFilePath, null);
			} catch (IOException e) {
				e.printStackTrace();
			}
		} else if (importFilePath.endsWith("txt") || importFilePath.endsWith("tsv")) {
			//TSV
	    	try {
	    		readList = MyFiles.parseTSV(importFilePath, "MS932");	//"SJIS" or "UTF-8"
			} catch (IOException e) {
				e.printStackTrace();
			}
		} else if (importFilePath.endsWith("csv")) {
			//CSV
	    	try {
	    		readList = MyFiles.parseCSV(importFilePath, "SJIS");
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		return readList;
	}

	private static ArrayList<String> getConvList(String toriCd) throws IOException {
		String xlsPath = "impChu.xlsx";
		MyExcel xlsx = new MyExcel();
		xlsx.open(xlsPath, "変換表", true);
		MyUtils.SystemLogPrint("  Excelオープン...: " + xlsPath);

		Cell cell;
		CellType ctype;
		String strValue;
	    ArrayList<String> convList = null;
		for (Row row : xlsx.sheet) {
			cell = row.getCell(0);		//A列
			strValue = cell.getStringCellValue();
			if (strValue.equals(toriCd)==true) {
				convList = new ArrayList<String>();
			    int startCol = 0;
				int endCol = 741;
			    for (int c=startCol; c<endCol; c++) {
			    	cell = row.getCell(c);
					ctype = cell.getCellType();
					if (ctype == CellType.NUMERIC) {
						int val = (int)xlsx.getNumericCellValue();
						strValue =  String.valueOf(val);
					} else {
						strValue = xlsx.getStringCellValue();
					}
			    	convList.add(strValue);
			    }
				break;
			}
			//空行までサーチ
			cell = row.getCell(6);			//G列
			if (cell == null) {
                break;
			}
		}

		xlsx.close();

		return convList;
	}

	//------------------------------------------------------
	//ファイル添付メール送信
	//------------------------------------------------------
	private static int sendAttachMail() {
		MyUtils.SystemLogPrint("  メール送信...");
		MyUtils.SystemLogPrint("  MAIL FmAddr: " + mailConf.fmAddr);
		MyUtils.SystemLogPrint("  MAIL ToAddr: " + mailConf.toAddr);
		MyUtils.SystemLogPrint("  MAIL CcAddr: " + mailConf.ccAddr);
		MyUtils.SystemLogPrint("  MAIL BcAddr: " + mailConf.bccAddr);
		MyUtils.SystemLogPrint("  MAIL Subject: " + mailConf.subject);
		MyUtils.SystemLogPrint("  MAIL Body: \n" + mailConf.body);
		MyUtils.SystemLogPrint("  MAIL Attach: " + mailConf.attach);
		mailConf.sendRawMail();

		return 0;
	}
}
