package tools.poimport;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.example.demo.SpringConfig;

import common.utils.MyDBInfo;
import common.utils.MyUtils;

public class PoImportDAO {
	//DB接続情報
	String DB_URL;
	String DB_USER;
	String DB_PASS;
	String DB_DRIVER;

	public PoImportDAO(SpringConfig config) {
        //接続情報取得
		DB_URL = config.getDBUrl();
		DB_USER = config.getDBUsername();
		DB_PASS = config.getDBPassword();
		DB_DRIVER = config.getDBDriverClassName();
	}

	public PoImportDAO(MyDBInfo dBInfo) {
        //接続情報取得
		DB_URL = dBInfo.URL;
		DB_USER = dBInfo.USER;
		DB_PASS = dBInfo.PASS;
		DB_DRIVER = dBInfo.DRIVER;
	}

	// インスタンスオブジェクトの生成->返却（コードの簡略化）
	public static PoImportDAO getInstance(SpringConfig config) {
		return new PoImportDAO(config);
	}

	public static PoImportDAO getInstance(MyDBInfo dBInfo) {
		return new PoImportDAO(dBInfo);
	}

	public int getCountChumonNo(String base) {
		String sql = "select count(CHUMON_NO) from CHUMON where COMP='00' and TORI_CD=? and JIGYO='00' order by CHUMON_NO";

		//接続処理
		Connection conn = null;
		try {
			Class.forName(DB_DRIVER);
			conn = DriverManager.getConnection(DB_URL,DB_USER,DB_PASS);
			System.out.println(sql);

			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, base);
			ResultSet rs = ps.executeQuery();

			int count = 0;
			while(rs.next()) {
   	            count = rs.getInt("(CHUMON_NO)");
			}
			return count;
		} catch(SQLException e) {
			// エラーハンドリング
			System.out.println("sql実行失敗");
			e.printStackTrace();
		} catch(ClassNotFoundException e) {
			// エラーハンドリング
			System.out.println("JDBCドライバ関連エラー");
			e.printStackTrace();
		} finally {
			// DB接続を解除
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

		return -1;
	}

	public ArrayList<String> getBaseChumonNo(String base, int size) {
		String sql = "select CHUMON_NO from CHUMON where COMP='00' and TORI_CD=? and JIGYOBU_CD='00' order by CHUMON_NO and rownum<=?";

		//接続処理
		Connection conn = null;
		try {
			Class.forName(DB_DRIVER);
			conn = DriverManager.getConnection(DB_URL,DB_USER,DB_PASS);
			System.out.println(sql);

			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, base);
			ps.setInt(1, size);
			ResultSet rs = ps.executeQuery();

			ArrayList<String> list = new ArrayList<String>();
			String strValue = null;
			while(rs.next()) {
	            strValue = rs.getString(1);
	            list.add(strValue);
			}
			return list;
		} catch(SQLException e) {
			// エラーハンドリング
			System.out.println("sql実行失敗");
			e.printStackTrace();
		} catch(ClassNotFoundException e) {
			// エラーハンドリング
			System.out.println("JDBCドライバ関連エラー");
			e.printStackTrace();
		} finally {
			// DB接続を解除
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

		return null;
	}

	public String getRefSeidenNo(String toriCd, String kyakuPn) {
		if (toriCd==null || kyakuPn==null) {
			return "";
		}

		String sql = "select DENPYO_NO from (select DENPYO_NO from RIREKI where TORI_CD=? and KYAKU_PN=? order by TOUROKU_DT) wher rownum=1"; 

		//接続処理
		Connection conn = null;
		String strValue = null;
		try {
			Class.forName(DB_DRIVER);
			conn = DriverManager.getConnection(DB_URL,DB_USER,DB_PASS);
			System.out.println(sql);

			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, toriCd);
			ps.setString(2, kyakuPn);
			ResultSet rs = ps.executeQuery();

			while(rs.next()) {
				strValue = rs.getString(1);
			}
			return strValue;
		} catch(SQLException e) {
			// エラーハンドリング
			System.out.println("sql実行失敗");
			e.printStackTrace();
		} catch(ClassNotFoundException e) {
			// エラーハンドリング
			System.out.println("JDBCドライバ関連エラー");
			e.printStackTrace();
		} finally {
			// DB接続を解除
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

		return null;
	}

	public String getToriMei(String toriCd) {
		String sql = "select TORI_MEI from TORI_MST where TORI_CD=?"; 

		//接続処理
		Connection conn = null;
		String strValue = null;
		try {
			Class.forName(DB_DRIVER);
			conn = DriverManager.getConnection(DB_URL,DB_USER,DB_PASS);
			System.out.println(sql);

			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, toriCd);
			ResultSet rs = ps.executeQuery();

			while(rs.next()) {
				strValue = rs.getString(1);
			}
			return strValue;
		} catch(SQLException e) {
			// エラーハンドリング
			System.out.println("sql実行失敗");
			e.printStackTrace();
		} catch(ClassNotFoundException e) {
			// エラーハンドリング
			System.out.println("JDBCドライバ関連エラー");
			e.printStackTrace();
		} finally {
			// DB接続を解除
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

		return null;
	}

	public String makeChumonSql(PoImportBean poImp) {
		String sql = "update CHUMON set registereddt=sysdate,updateddt=sysdate,SHAISHU_KOSHI_DATETIME=sysdate,SHINSAKU_REPEAT_KBN=?,SEIDEN_KBN=%s,"
				   + "EIGYOSHO_CD='%s',EIGYO_SOSHIKI_CD='%s',EIGYO_TANTOSHA_CD='%s',SHUKEI_CD='%s',JIGYOBU_CD='%s',KAKOBUMON_CD='%s',"
				   + "TORIHIKISAKI_CD='%s',KYAKUSAKI_PARTS_NO='%s',KYAKUSAKI_CHUMON_BANGO='%s',"
				   + "JIGYOBU_CD='%s',JUCHU_ZUMEN_BANGO='%s',JUCHU_SPEC='%s',EIGYO_NOTE='%s',"
				   + "IRAISAKIMOTO_JIGYOSHO_CD='%s',IRAISAKI_BUMON_CD='%s',HINSHU_CD1='%s',HINSHU_CD2='%s',ZAISHITSU_CD='%s',"
				   + "SURYO='%s',SEIZOU_TANKA='%s',KATADAI='%s',KYAKUSAKI_HINMEI1='%s',SANSHO_TORIHIKISAKI_CD='%s',SANSHO_KYAKUSAKI_PARTS_NO='%s',SANSHO_SEIDEN_NO='%s'"
				   + " where CHUMON_NO=%s;";
		sql = String.format(sql, poImp.shinsakuRepeat, poImp.seidenKbn, poImp.eigyoSho, poImp.eigyoSoshiki, poImp.tantoshaCd, poImp.shukeiCd,
				poImp.jigyobuCd, poImp.kakoCd, poImp.toriCd, poImp.kyakuPn, poImp.chuban, poImp.jigyobuCd, poImp.zuban, poImp.spec, poImp.noteRan, 
				poImp.iraisakiJigyosSho, poImp.iraisakiKakoCd, poImp.hinshu1Cd, poImp.hinshu2Cd, poImp.zaishitsuCd, 
				poImp.suryo, poImp.tanka, poImp.katadai, poImp.hinmei1, poImp.toriCd, poImp.kyakuPn, poImp.refSeidenNo, poImp.chumonNo);

		return sql;
	}

	public String makeMeisaiSql(PoImportBean poImp, int meisaiNo) {
		String yoteiMonth = poImp.meisaiList.get(meisaiNo).yoteiMonth;
		String yoteiSuryo = poImp.meisaiList.get(meisaiNo).yoteiSuryo;
		if (yoteiMonth.equals("")==true || yoteiSuryo.equals("")==true )
			return null;
		Double suryo = 0.0;
		Double tanka = 0.0;
		int kingaku = 0;
		try {
			suryo = Double.parseDouble(yoteiSuryo);
		} catch(NumberFormatException e) {
			MyUtils.SystemErrPrint("数量: 数値NG " + yoteiSuryo);
		}
		try {
			tanka = Double.parseDouble(poImp.tanka);
		} catch(NumberFormatException e) {
			MyUtils.SystemErrPrint("単価: 数値NG " + poImp.tanka);
		}
		kingaku = (int) Math.floor(suryo*tanka);

		String sql = "update MEISAI set registereddt=sysdate,updateddt=sysdate, "
				   + "JUCHU_YOTEI_MONTH='%s',suryo='%s',SEIZOU_KEIYAKU_TANKA='%s',KATADAI='%s',KINGAKU='%s',SA_KINGAU='%s',"
				   + "EIGYOSHO_CD='%s',EIGYO_SOSHIKI_CD='%s',EIGYO_TANTOSHA_CD='%s',SHUKEI_CD='%s',JIGYOBU_CD='%s',KAKOBUMON_CD='%s',"
				   + "TORIHIKISAKI_CD='%s',KYAKUSAKI_PARTS_NO='%s',KYAKUSAKI_HINMEI1='%s',JUCHU_ZUMEN_BANGO='%s'"
				   + " where CHUMON_NO='%s' and CHUMON_MEISAI_NO='%s';";
		sql = String.format(sql,yoteiMonth, poImp.tanka, poImp.katadai, kingaku, kingaku, 
				poImp.eigyoSho, poImp.eigyoSoshiki, poImp.tantoshaCd, poImp.shukeiCd, poImp.jigyobuCd, poImp.kakoCd, 
				poImp.toriCd, poImp.kyakuPn, poImp.hinmei1, poImp.zuban, 
				poImp.chumonNo, meisaiNo);

		return sql;
	}

	public String makeBunouSql(PoImportBean poImp, int meisaiNo) {
		String youkyuDate = poImp.noukiList.get(meisaiNo).youkyuDate;
		String youkyuSuryo = poImp.noukiList.get(meisaiNo).youkyuSuryo;
		String kibouDate = poImp.noukiList.get(meisaiNo).kibouDate;
		String kibouSuryo = poImp.noukiList.get(meisaiNo).kibouSuryo;
		String sql = null;
		if (meisaiNo == 0) {
			sql = "update BUNNOU set registereddt=sysdate,updateddt=sysdate"
			    + "KYAKUSAKI_YOKYU_NOKI='%s',KYAKUSAKI_YOKYU_SU='%s',"
			    + "EIGYO_KIBO_NOKI='%s',EIGYO_KIBO_SU='%s',SEIZO_RENRAKU_MEMO='%s'"
			    + " where CHUMON_NO='%s' and NOKI_MEISAI_NO='%s';";
			sql = String.format(sql,youkyuDate, youkyuSuryo, kibouDate, kibouSuryo, poImp.renrakuMemo, 
					poImp.chumonNo, meisaiNo);
		} else {
			poImp.renrakuMemo = "";
			sql = "insert into BUNNOU value ('00','%s',sysdate,'%s',sysdate,"
				+ "'%s','%s','%s','%s','%s','%s','%s','','','','','','')";
			sql = String.format(sql, "reg", "reg", "exflag", poImp.chumonNo, meisaiNo, 
					youkyuDate, youkyuSuryo, kibouDate, kibouSuryo);
		}
		return sql;
	}

	public void executeUpdate(String sql) {
		//接続処理
		Connection conn = null;
		try {
			Class.forName(DB_DRIVER);
			conn = DriverManager.getConnection(DB_URL,DB_USER,DB_PASS);
			System.out.println(sql);
			conn.setAutoCommit(false);

			PreparedStatement ps = conn.prepareStatement(sql);

			ps.executeUpdate();
			conn.commit();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// DB接続を解除
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}
}
