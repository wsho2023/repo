package tools.poimport;

import java.util.ArrayList;

public class PoImportBean {
	public PoImportBean() {
		meisaiList = new ArrayList<Meisai>();
		for (int m=0; m<41; m++) {
			Meisai meisai = new Meisai();
			meisaiList.add(meisai);
		}
		noukiList = new ArrayList<Nouki>();
		for (int n=0; n<41; n++) {
			Nouki nouki = new Nouki();
			noukiList.add(nouki);
		}
	}
	//-----------------------------------------------
	//注文ヘッダ
	//-----------------------------------------------
	public String eigyoSho;
	public String eigyoSoshiki;
	public String tantoshaCd;
	public String shukeiCd;
	public String shinsakuRepeat;
	public String jigyoSho;
	public String kakoCd;
	public String seidenKbn;

	public String toriCd;
	public String kyakuPn;
	public String chuban;
	public String suryo;
	public String tanka;
	public String katadai;
	public String jigyobuCd;
	public String zuban;
	public String spec;
	public String hinmei1;
	public String hinmei2;
	public String hinshu1Cd;
	public String hinshu2Cd;
	public String zaishitsuCd;
	public String iraisakiJigyosSho;
	public String iraisakiKakoCd;

	public String chumonNo;
	public String newSeidenNo;
	public String sofuCd;
	public String renrakuMemo;
	public String noteRan;

	public ArrayList<Meisai> meisaiList;
	public ArrayList<Nouki> noukiList;

	public String refSeidenNo;
}

class Meisai {
	String meisaiNo;
	String yoteiMonth;
	String yoteiSuryo;
	String kingaku;
};

class Nouki {
	String kibouDate;
	String kibouSuryo;
	String youkyuDate;
	String youkyuSuryo;
};

