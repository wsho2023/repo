package com.scchemical;

import java.util.ArrayList;

import lombok.Data;

@Data
public class SetsubiCheckDataBean {
	int no;
	//String checkPoint;
	String checkItem;
	String frequency;
	ArrayList<DispKekka> checkKekka;
	
	SetsubiCheckDataBean() {
		checkKekka = new ArrayList<DispKekka>();
	}
	
	void addTenkenKekka(String tenken, String style) {
		DispKekka tnekenKekka = new DispKekka(tenken, style);
		checkKekka.add(tnekenKekka);
	}
}

