package com.scchemical;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import common.utils.MyUtils;

@Controller
public class SetsubitenkenController {
	@Autowired
	private SpringConfig config;
	
	String[] constSpecNoList = {"SC-60WS2037", "SC-60WS0002", "SC-61WS2025"};
	String[] constSyozokuKaList = {"開発課1", "開発課2", "開発課3"};
	String[][] constSetsubiMeiList = {
			{"153-SW", "154-SW", "155-SW"},
			{"253-SW", "254-SW", "255-SW"},
			{"353-SW", "354-SW", "355-SW"},
	};

	String[][] specList = {
		{"","","","",""},
		{"53-SW","#1-3F","SC-60WS2037-53","#5クレーン","フレコン積み替え"},
		{"54-SW","#2-3F","SC-60WS2037-54","#7クレーン","フレコン積み替え"},
		{"55-SW","#3-3F","SC-60WS2037-55","#7クレーン","フレコン積み替え"},
	};
	
	//53-SW
	String[][] checkPoint_53_5_crane = { //9項目
		{"ペンダントスイッチの不備はないか","1日/1回"},
		{"キャプタイヤコードに破損はないか","1日/1回"},
		{"クラブ電源コードに破損はないか","1日/1回"},
		{"ペンダントスイッチの不備はないか","1日/1回"},
		{"キャプタイヤコードに破損はないか","1日/1回"},
		{"クラブ電源コードに破損はないか","1日/1回"},
		{"ペンダントスイッチの不備はないか","1日/1回"},
		{"キャプタイヤコードに破損はないか","1日/1回"},
		{"クラブ電源コードに破損はないか","1日/1回"},
	};
	
	//----------------------------------------------------
    @GetMapping("/")
	//----------------------------------------------------
    public String tenkenListGet(Model model){
		MyUtils.SystemLogPrint("■get: /");
    	SetsubiTenkenHeadBean header = new SetsubiTenkenHeadBean();
		//----------------------------------------------------
		//年/月度
		//----------------------------------------------------
    	Date dtNow = new Date();
    	String year = "";
    	String month = "";
    	MyUtils.SystemLogPrint("now: " + dtNow);
    	if (year.equals("") == true) {
    		SimpleDateFormat ysdf = new SimpleDateFormat("yyyy");
    		header.year = ysdf.format(dtNow);
    	} else {
    		header.year = year;
    	}
    	if (month.equals("") == true) {
    		SimpleDateFormat msdf = new SimpleDateFormat("M");
    		header.month = msdf.format(dtNow);
    	} else {
    		header.month = month;
    	}
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		header.today = sdf.format(dtNow);
		//----------------------------------------------------
        //年月から、日付/曜日取得
		//----------------------------------------------------
		String dayFull;
		Calendar cal = Calendar.getInstance();
		DayWeek dw;
		for (int d=1; d<=31; d++) {
			dw = new DayWeek();
			dayFull = header.year + "/" + String.format("%02d", (Integer.parseInt(header.month))) + "/" + String.format("%02d", d);
			if (checkDate(dayFull) == true) {
				dw.day = Integer.valueOf(d).toString();
				cal.set(Integer.parseInt(header.year), Integer.parseInt(header.month)-1, d);	//月は0~11で設定
				dw.week = getYoubiName(cal);
				//System.out.println(dayFull + " " + youbi);
			} else {
				dw.day= "";
				dw.week = "";
			}
			header.dayWeekList.add(dw);
    	}
        MyUtils.SystemLogPrint("year: " + header.year + " month: " + header.month);
		//----------------------------------------------------
        //リストボックス用
		//----------------------------------------------------
        //ArrayList<String> syozokuKaList = new ArrayList<String>();
        int i=0;
        ArrayList<String> kaSetsubiMeiList = null;
        for (String ka : constSyozokuKaList) {
        	header.syozokuKaList.add(ka);
        	kaSetsubiMeiList = new ArrayList<String>();
            for (String mei : constSetsubiMeiList[i]) {
            	kaSetsubiMeiList.add(mei);
            }
            header.setsubiMeiList.add(kaSetsubiMeiList);
            i++;
        }
        //ArrayList<String> setsubiMeiList = new ArrayList<String>();
		//----------------------------------------------------
        //建屋/設備名/工程名/設備NO
		//----------------------------------------------------
//        String secchiBasyo = "";
//        String syozokuKa = "";
//        String kanriNo = "";
//        String setsubiMei = "";
//        System.out.println("secchiBasyo:" + secchiBasyo + " syozokuKa:" + syozokuKa);
//        System.out.println("kanriNo:" + kanriNo + " setsubiMei:" + setsubiMei);
		//----------------------------------------------------
		//点検項目/結果取得
		//----------------------------------------------------
        ArrayList<SetsubiCheckDataBean> checkDatalist = new ArrayList<SetsubiCheckDataBean>();
        SetsubiCheckDataBean checkData;
        ArrayList<DispKekka> tenkenList = new ArrayList<DispKekka>();
        ArrayList<DispKekka> shochiList = new ArrayList<DispKekka>();
        DispKekka tenken = new DispKekka();
        for (int n=0; n<4; n++) {
        	checkData = new SetsubiCheckDataBean();;
        	checkData.setNo(n+1); 
        	//checkData.setCheckPoint("");
        	checkData.setCheckItem("");
        	checkData.setFrequency("");
        	String yearmonth = year + "/" + month + "/";
        	String day = null;
    		for (int d=1; d<=31; d++) {
    			day = yearmonth + String.format("%02d", d);	//0埋め2桁
    			dw = header.dayWeekList.get(d-1);
				if (dw.week.equals("土") || dw.week.equals("日")) {	//追加で祝日
    				checkData.addTenkenKekka("/", "background-color:#cac7c7;");
    			} else {
    				checkData.addTenkenKekka("", "");
    			}
    		}
    		checkDatalist.add(checkData);
        }
		for (int d=1; d<=31; d++) {
			dw = header.dayWeekList.get(d-1);
			if (dw.week.equals("土") || dw.week.equals("日")) {	//追加で祝日
				tenken = new DispKekka("/", "background-color:#cac7c7;");
				tenkenList.add(tenken);
				tenken = new DispKekka("/", "background-color:#cac7c7;");
				shochiList.add(tenken);
			} else {
				tenken = new DispKekka("","");
				tenkenList.add(tenken);
				tenken = new DispKekka("","");
				shochiList.add(tenken);
			}
		}
        //----------------------------------------------------
		// 次の画面に値を渡す
        //----------------------------------------------------
		model.addAttribute("header", header);
        model.addAttribute("checklist", checkDatalist);
        model.addAttribute("tenkenList", tenkenList);
        model.addAttribute("shochiList", shochiList);
        //----------------------------------------------------
		// 次の画面に遷移
        //----------------------------------------------------
		return "tenkenlist";
    }

    //----------------------------------------------------
    @PostMapping("/")
    //----------------------------------------------------
    public String tenkenListPost(Model model,
      	@RequestParam(name="text_year", required = false) String year,
      	@RequestParam(name="list_month", required = false) String month,
    	@RequestParam(name="list_ka", required = false) String syozokuKa,
    	@RequestParam(name="list_setsubi", required = false) String setsubiMei) {
    	
		MyUtils.SystemLogPrint("■post: /");
    	SetsubiTenkenHeadBean header = new SetsubiTenkenHeadBean();
		//----------------------------------------------------
		//年/月度
		//----------------------------------------------------
    	Date dtNow = new Date();
    	MyUtils.SystemLogPrint("now: " + dtNow);
    	if (year.equals("") == true) {
    		SimpleDateFormat ysdf = new SimpleDateFormat("yyyy");
    		header.year = ysdf.format(dtNow);
    	} else {
    		header.year = year;
    	}
    	if (month.equals("") == true) {
    		SimpleDateFormat msdf = new SimpleDateFormat("M");
    		header.month = msdf.format(dtNow);
    	} else {
    		header.month = month;
    	}
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		header.today = sdf.format(dtNow);
		//----------------------------------------------------
		//年月から、日付/曜日取得
		//----------------------------------------------------
		String dayFull;
		Calendar cal = Calendar.getInstance();
		DayWeek dw;
		for (int d=1; d<=31; d++) {
			dw = new DayWeek();
			dayFull = header.year + "/" + String.format("%02d", (Integer.parseInt(header.month))) + "/" + String.format("%02d", d);
			if (checkDate(dayFull) == true) {
				dw.day = Integer.valueOf(d).toString();
				cal.set(Integer.parseInt(header.year), Integer.parseInt(header.month)-1, d);	//月は0~11で設定
				dw.week = getYoubiName(cal);
				//System.out.println(dayFull + " " + youbi);
			} else {
				dw.day = "";
				dw.week= "";
			}
			header.dayWeekList.add(dw);
    	}
        MyUtils.SystemLogPrint("year: " + header.year + " month: " + header.month);
		//----------------------------------------------------
        //リストボックス用
		//----------------------------------------------------
        int i=0;
        ArrayList<String> kaSetsubiMeiList = null;
        for (String ka : constSyozokuKaList) {
        	header.syozokuKaList.add(ka);
        	kaSetsubiMeiList = new ArrayList<String>();
            for (String mei : constSetsubiMeiList[i]) {
            	kaSetsubiMeiList.add(mei);
            }
            header.setsubiMeiList.add(kaSetsubiMeiList);
            i++;
        }
		//----------------------------------------------------
    	//建屋/設備名/工程名/設備NO
		//----------------------------------------------------
    	header.secchiBasyo = "";
    	header.kanriNo = "";
        header.syozokuKa = syozokuKa;
        header.setsubiMei = setsubiMei;
        MyUtils.SystemLogPrint("secchiBasyo:" + header.secchiBasyo + " syozokuKa:" + header.syozokuKa);
        MyUtils.SystemLogPrint("kanriNo:" + header.kanriNo + "setsubiMei:" + header.setsubiMei);
		//----------------------------------------------------
		//点検項目/結果取得
		//----------------------------------------------------
		String checkPoint[][] = null;
		for (int s=0; s<specList.length; s++) {
			if (setsubiMei.equals(specList[s][0])==true) {
				header.secchiBasyo = specList[s][1];
				header.kanriNo = specList[s][2];
				//koteiMei = specList[s][4];
				//if (setsubiNo.equals("53-SW")) {
				//	checkPoint = new String[checkPoint_53_5_crane.length][];
				//	checkPoint = checkPoint_53_5_crane;
				//}
				break;
			}
		}
		checkPoint = new String[checkPoint_53_5_crane.length][];
		checkPoint = checkPoint_53_5_crane;
        System.out.println("year:" + header.year + " month:" + header.month);
        System.out.println("secchiBasyo:" + header.secchiBasyo + " syozokuKa:" + syozokuKa);
        System.out.println("kanriNo:" + header.kanriNo + " setsubiMei:" + setsubiMei);
		//----------------------------------------------------
        //点検結果取得
		//----------------------------------------------------
        //MyDBInfo dbInfo = config.getDBInfo();
        ArrayList<SetsubiCheckDataBean> checkDatalist = new ArrayList<SetsubiCheckDataBean>();
        SetsubiCheckDataBean checkData;
        ArrayList<DispKekka> tenkenList = new ArrayList<DispKekka>();
        ArrayList<DispKekka> shochiList = new ArrayList<DispKekka>();
        DispKekka tenken = new DispKekka();
        int checkItemSize = checkPoint.length;
        for (int n=0; n<checkItemSize; n++) {
        	checkData = new SetsubiCheckDataBean();;
        	checkData.setNo(n+1); 
        	//checkData.setCheckPoint(checkPoint[n][0]);
        	checkData.setCheckItem(checkPoint[n][0]);
        	checkData.setFrequency(checkPoint[n][1]);
        	String yearmonth = year + "/" + month + "/";
        	//String day = null;
    		for (int d=1; d<=31; d++) {
    			//day = yearmonth + String.format("%02d", d);	//0埋め2桁
    			dw = header.dayWeekList.get(d-1);
				if (dw.week.equals("土") || dw.week.equals("日")) {	//追加で祝日
					checkData.addTenkenKekka("/", "background-color:#cac7c7;");
					//checkData.checkKekka.add("/");
					tenken = new DispKekka("/", "background-color:#cac7c7;");
				} else {
    				checkData.addTenkenKekka("", "");
					//checkData.checkKekka.add("");
    				tenken = new DispKekka("", "");
				}
    		}
    		checkDatalist.add(checkData);
        }
		for (int d=1; d<=31; d++) {
			dw = header.dayWeekList.get(d-1);
			if (dw.week.equals("土") || dw.week.equals("日")) {	//追加で祝日
				tenken = new DispKekka("/", "background-color:#cac7c7;");
				tenkenList.add(tenken);
				tenken = new DispKekka("/", "background-color:#cac7c7;");
				shochiList.add(tenken);
			} else {
				tenken = new DispKekka("","");
				tenkenList.add(tenken);
				tenken = new DispKekka("","");
				shochiList.add(tenken);
			}
		}

        //----------------------------------------------------
		// 次の画面に値を渡す
        //----------------------------------------------------
		model.addAttribute("header", header);
        model.addAttribute("checklist", checkDatalist);
        model.addAttribute("tenkenList", tenkenList);
        model.addAttribute("shochiList", shochiList);
        //System.out.println("setsubiNo:" + setsubiNo);
        //System.out.println("listNo:" + listNo);
        //----------------------------------------------------
		// 次の画面に遷移
        //----------------------------------------------------
    	return "tenkenlist";
    }

    @PostMapping("/clear")
    public String tenkenListPost(Model model){
    	
		MyUtils.SystemLogPrint("■post: /clear");
		//初期化
    	return tenkenListGet(model);
    }

    @PostMapping("/datain")
    @ResponseBody	//＠ResponseBody アノテーションを付けることで、戻り値を HTTP レスポンスのコンテンツとすることができます。
    public String dataInPost(Model model,
        @RequestParam(name="text_type", required = false) String type,
      	@RequestParam(name="text_name", required = false) String name,
      	@RequestParam(name="text_date", required = false) String date,
    	@RequestParam(name="text_section", required = false) String section) {
    	
    	MyUtils.SystemLogPrint("type: " + type);
    	MyUtils.SystemLogPrint("name: " + name);
    	MyUtils.SystemLogPrint("date: " + date);
    	MyUtils.SystemLogPrint("sect: " + section);
    	//レスポンス
		return "{\"result\":\"ok\"}";
    }

    private boolean checkDate(String strDate) {
        if (strDate == null || strDate.length() != 10) {
            throw new IllegalArgumentException(
                    "引数の文字列["+ strDate +"]" +
                    "は不正です。");
        }
        strDate = strDate.replace('-', '/');
        DateFormat format = DateFormat.getDateInstance();
        // 日付/時刻解析を厳密に行うかどうかを設定する。
        format.setLenient(false);
        try {
            format.parse(strDate);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private String getYoubiName(Calendar cal) {
    	String youbi = "";
    	// 日付から曜日を取得する
    	switch (cal.get(Calendar.DAY_OF_WEEK)) { 
    	case Calendar.SUNDAY:     // Calendar.SUNDAY:1 
    		//日曜日
    		youbi = "日";
    		break;
    	case Calendar.MONDAY:     // Calendar.MONDAY:2
    		//月曜日
    		youbi = "月";
    		break;
    	case Calendar.TUESDAY:    // Calendar.TUESDAY:3
    		//火曜日
    		youbi = "火";
    		break;
    	case Calendar.WEDNESDAY:  // Calendar.WEDNESDAY:4
    		//水曜日
    		youbi = "水";
    		break;
    	case Calendar.THURSDAY:   // Calendar.THURSDAY:5
    	    //木曜日
    		youbi = "木";
    		break;
    	case Calendar.FRIDAY:     // Calendar.FRIDAY:6
    		//金曜日
    		youbi = "金";
    		break;
    	case Calendar.SATURDAY:   // Calendar.SATURDAY:7
    		//土曜日
    		youbi = "土";
    		break;
    	}
    	 return youbi;
    }
}
