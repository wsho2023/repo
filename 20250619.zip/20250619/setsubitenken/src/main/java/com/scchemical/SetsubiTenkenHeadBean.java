package com.scchemical;

import java.util.ArrayList;

import lombok.Data;

@Data
public class SetsubiTenkenHeadBean {
	String year;
  	String month;
  	String today;
	String syozokuKa;
	String setsubiMei;
	String secchiBasyo;
	String kanriNo;	
    ArrayList<String> monthList;
    ArrayList<String> syozokuKaList;
    ArrayList<ArrayList<String>> setsubiMeiList;	//所属課ごとに、設備リストあり
	ArrayList<DayWeek> dayWeekList;
    
    SetsubiTenkenHeadBean() {
		monthList = new ArrayList<String>();
		for (int i=1; i<=12; i++) {
			monthList.add(Integer.valueOf(i).toString());
		}
    	syozokuKaList = new ArrayList<String>();
    	setsubiMeiList = new ArrayList<ArrayList<String>>();
		dayWeekList = new ArrayList<DayWeek>();
    }
}
