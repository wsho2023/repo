package com.scchemical;

import lombok.Data;

@Data
public class DispKekka {
	String value;
	String style;
	
	DispKekka() {
		
	}
	DispKekka(String argValue, String argStyle) {
		this.value = argValue;
		this.style = argStyle;
	}
}
