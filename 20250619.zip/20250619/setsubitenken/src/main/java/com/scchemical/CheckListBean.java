package com.scchemical;

import java.io.Serializable;
import java.util.ArrayList;

public class CheckListBean implements Serializable {
    String checkPoint;
    String checkItem;
    String frequency;
    ArrayList<String> check;
	
	public CheckListBean() {
		check = new ArrayList<String>();
    }

    public String getCheckPoint() { return this.checkPoint; }
    public String getCheckItem() { return this.checkItem; }
    public String getFrequency() { return this.frequency; }
    
    public String getCheck(int day) { return this.check.get(day); }
}
