package com.scchemical;

public class DayWeek {
	String day;
	String week;
	
	public String getDay() {
		return day;
	}

	public String getWeek() {
		return week;
	}
}
